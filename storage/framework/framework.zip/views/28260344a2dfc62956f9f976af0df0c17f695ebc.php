<?php $__env->startSection('content'); ?>
<?php echo $__env->make('custom.inc.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('custom.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="create-page inner-padding-top">
    <div class="container default-container">
        <div class="row marginleftright">
            <div class="col-md-12">
                <div class="create-page-section">
                    <form class="page__form" action="<?php echo e(route('group.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                       <div class="page__identity">
                          <h3>Create Group</h3>

                          <div class="form__input--floating">
                            <label class="form__label--floating" id="label--tagline">Group Name </label>
                            <input id="input--tagline" type="text" placeholder="" name="name" required/>
                          </div>
                          <div class="form__input--floating">
                            <label class="form__label--floating" id="label--tagline">About Group</label>
                            <textarea id="input--tagline" type="text" placeholder="" name="about" required></textarea>
                          </div>

                           <div class="upload-preview">
                            <label class="form__label--floating" id="label--logo">Logo </label>
                            <input id="input--logo" type="file" placeholder="" name="log" required>
                            <label class="form__label--floating">recommended. JPGs, JPEGs, and PNGs supported.</label>
                          </div>
                          <div class="upload-preview">
                            <label class="form__label--floating" id="label--logo">Banner </label>
                            <input id="input--logo" type="file" placeholder="" name="ban" required>
                            <label class="form__label--floating">recommended. JPGs, JPEGs, and PNGs supported.</label>
                          </div>
                      </div>

                      <div class="login__form_action_container login__form_action_container--multiple-actions">
                        <input type="submit" class="btn btn-page btn__primary--large from__button--floating" value="Create Group">
                      </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('custom.inc.chatWidget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('custom.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/group/createGroup.blade.php ENDPATH**/ ?>