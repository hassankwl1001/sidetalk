<?php $__env->startSection('content'); ?>
<?php echo $__env->make('custom.inc.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('custom.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
    .scroll::-webkit-scrollbar {
        display: none;
    }
</style>
    <!-- MAIN CONTAINER -->
    <div class="container">
        <!-- PROFILE -->
        <section id="profile">

        </section>
        <!-- LEFT ASIDE -->
        <div class="left-aside-wrapper" id="left-aside-wrapper">
            <aside class="left-aside" id="left-aside">
                <div class="profile-groups" id="profile-groups">
                    <section class="profiles-section">
                        <header>
                            <span>Messages</span>
                            
                        </header>
                        <div class="searchbar default-bar">
                            <input class="form-control" id="search" type="text" placeholder="Search">
                            <span id="search-icon" class="fas fa-search" aria-hidden="true"></span>
                        </div>
                        <ul class="group-list" id="conversationList">
                            <?php if(isset($user)): ?>
                                <li class="messages-lists" data-user="<?php echo e($user->id); ?>">
                                    <figure class="image-container">
                                        <img class="img-size" src="<?php echo e($user->profile_pic != null ? $profileUrl.'/'.$user->profile_pic : asset('assets/img'). '/profile.png'); ?>" alt="">
                                    </figure>
                                    <div class="box-commented">
                                        <div class="commented-description">
                                            <strong class="post_name"><?php echo e($user->firstname." ". $user->lastname); ?></strong>
                                        </div>
                                        <span class="designation"><?php echo e($user->current_position != null ?  $user->current_position : 'No designation'); ?></span>
                                    </div>
                                </li>
                            <?php endif; ?>

                            <?php $__empty_1 = true; $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>


                                <li class="messages-lists" data-user="<?php echo e($conversation->sender == null ? $conversation->receiver->id : $conversation->sender->id); ?>">
                                    <figure class="image-container">
                                        <img class="img-size" src="<?php echo e($conversation->profile_pic != null ? $profileUrl.$profile_pic : asset('assets/img'). '/profile.png'); ?>" alt="">
                                    </figure>
                                    <div class="box-commented">
                                        <div class="commented-description">
                                            <strong class="post_name"><?php echo e($conversation->sender == null ? $conversation->receiver->firstname." ". $conversation->receiver->lastname : $conversation->sender->firstname." ". $conversation->sender->lastname); ?></strong>
                                        </div>
                                        <span class="designation"><?php echo e($conversation->current_position != null ?  $conversation->current_position : 'No designation'); ?></span>
                                    </div>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                No Conversation found
                            <?php endif; ?>

                        </ul>
                    </section>
                </div>
            </aside>
        </div>
        <!-- MAIN -->
        <div id="main-wrapper">
            <main class="main-section" id="main-section">
                <article id="chatbox1" data-user="">
                    <div class="post-author">
                        <a href="#">
                            <div class="author-details">
                                <figure class="image-container">
                                    <img id="user_image" class="img-size" src="assets/img/Ellipse2.png" alt="">
                                </figure>
                                <div class="author-description">
                                    <div class="post-name-experience">
                                        <strong class="post-author-name" id="user_name">Akram Sheikh</strong>
                                    </div>
                                    <span class="designation" id="user_designation">Marketing & Operations at BTW
                                </div>
                            </div>
                        </a>



                    </div>
                    <div class="mesgs"  style="max-height: 500px;overflow-y: scroll" >
                      <div class="msg_history " id="conversation_chat"  >
                        <div class="incoming_msg">
                          <div class="incoming_msg_img"> <img src="assets/img/Ellipse2.png" alt=""> </div>
                          <div class="received_msg">
                            <div class="received_withd_msg">
                              <p>Hi!</p>
                            </div>
                          </div>
                        </div>
                        <div class="outgoing_msg">
                          <div class="sent_msg">
                            <p>Hey! how are you?</p>
                          </div>
                        </div>
                        <div class="incoming_msg">
                          <div class="incoming_msg_img"> <img src="assets/img/Ellipse2.png" alt=""> </div>
                          <div class="received_msg">
                            <div class="received_withd_msg">
                              <p>I am great!! What's Up?</p>
                          </div>
                          </div>
                        </div>
                      </div>

                    </div>
                    <div class="type_msg w-100">
                        <div class="input_msg_write w-100">
                            
                            
                            
                            <textarea id="send_message_on_enter" style="height: 43px;" class="write_msg w-100 p-1 scroll" placeholder="Type a message"></textarea>
                            <button class="msg_send_btn" type="button"><i class="fas fa-paper-plane mx-2" aria-hidden="true"></i></button>
                        </div>
                    </div>
                </article>
            </main>
        </div>
        <!-- RIGHT ASIDE -->
        <aside class="right-aside" id="right-aside">
            <div class="advertisement-section" id="advertisement-section">
                <div class="advertisement-portion">
                    <header>
                        <span>Advertisement</span>
                    </header>
                    <div class="advertisement-space">
                        <figure>
                            <img src="assets/img/advertisement.png" alt="">
                        </figure>
                    </div>
                </div>
            </div>
        </aside>
    </div>

    <?php echo $__env->make('custom.inc.consultationModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('custom.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/inbox.blade.php ENDPATH**/ ?>