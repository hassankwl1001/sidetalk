<?php $__env->startSection('content'); ?>
<?php echo $__env->make('custom.inc.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('custom.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('custom.inc.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="group-list inner-padding-top">
    <div class="container default-container">
        <div class="row marginleftright">
            <div class="col-12 paddingleftright">

                <div class="section-heading">
                    <h3>All Groups</h3>
                </div>
            </div>
            <div class="col-12 paddingleftright">
                <div class="group-lists">

                    <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="group-section">
                        <figure>
                            <img src="<?php echo e($url); ?>/<?php echo e($group->profile_pic); ?>" alt="" width="50" height="50">
                        </figure>
                        <div class="group-name">
                            <a href="<?php echo e(route('group.detail', $group->id)); ?>"><?php echo e($group->name); ?></a>
                            <p><?php echo e($group->members_count); ?> members</p>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p>No Group</p>
                    <?php endif; ?>

                </div>
            </div>
        </div>
    </div>
</section>


<?php echo $__env->make('custom.inc.chatWidget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('custom.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/group/allGroups.blade.php ENDPATH**/ ?>