<?php $__env->startSection('content'); ?>

    <style>
        .field-icon {
            float: right;
            margin-left: -25px;
            margin-top: -28px;
            margin-right: 6px;
            position: relative;
            z-index: 2;
        }
    </style>
<main class="signup__content">
    <div class="header__logo">
      <img src="<?php echo e(asset('assets/img/skilled.png')); ?>" alt="logo">
    </div>
    <!-- <div class="header__content">
      <h1 class="header__content__heading">Sign Up</h1>
    </div> -->
    <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','style' => 'color:red','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','style' => 'color:red','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    <form id="signform" class="login__form" action="<?php echo e(route('login')); ?>" method="post">
      <?php echo csrf_field(); ?>
      <fieldset>
        <h2 class="fs-title">SignIn Detail</h2>
        <h3 class="fs-subtitle">Give your login credentails</h3>
        <div class="form__input--floating">
          <label class="form__label--floating" id="label--email">Email</label>
          <input id="email" value="<?php echo e(old('email')); ?>" type="email" placeholder="abx@xyz.com" name="email" required>
            <small style="color: red" id="emailvalidation"></small>
        </div>
        <div class="form__input--floating">
          <label class="form__label--floating" id="label--password">Password</label>

          <input id="password-field"  type="password"  placeholder="******" name="password" required>
            <span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>

        </div>


        <div class="login__form_action_container login__form_action_container--multiple-actions">
          <input type="submit" class=" btn__primary--large from__button--floating" aria-label="Sign Up" value="Login" />
        </div>
        <div class="login__form_action_container text-center">
          <p>or</p>
        </div>
        <div class="login__form_action_container login__form_action_container--multiple-actions">
          <a  href="<?php echo e(route('login.google')); ?>" class="btn__secondary--large from__button--floating" aria-label="Join Google"><img src="<?php echo e(asset('assets/img/google-icon.png')); ?>" alt="google-icon" />Continue with Google</a>
        </div>
        <div class="footer-app-content-actions">
          <?php if(Route::has('password.request')): ?>
              <a href="<?php echo e(route('password.request')); ?>">
                  <?php echo e(__('Forgot your password?')); ?>

              </a>
          <?php endif; ?>

          <div class="login__para">
            <p>Please read our <a href="<?php echo e(route('policy')); ?>">privacy policy</a> & <a href="<?php echo e(route('terms')); ?>">terms of use</a> here</p>
          </div>
          <div class="Signin__class">
              <p>Create account on <img src="<?php echo e(asset('assets/img/skilled.png')); ?>" alt="">?<a href="<?php echo e(route('register')); ?>">Sign Up</a></p>
          </div>
        </div>
      </fieldset>
    </form>

</main>
    <script>
        $(document).ready(function () {
            $(document).on('keypress keydown','#email',function () {
                if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(signform.email.value))
                {
                    document.getElementById('emailvalidation').innerHTML=''
                    return
                }
                document.getElementById('emailvalidation').innerHTML='please enter valid email address'
                // alert("You have entered an invalid email address!")
                return
            })
            $(".toggle-password").click(function() {

                $(this).toggleClass("fa-eye fa-eye-slash");
                var input = $($(this).attr("toggle"));
                if (input.attr("type") == "password") {
                    input.attr("type", "text");
                } else {
                    input.attr("type", "password");
                }
            });
        })

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('custom.layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/custom/auth/login.blade.php ENDPATH**/ ?>