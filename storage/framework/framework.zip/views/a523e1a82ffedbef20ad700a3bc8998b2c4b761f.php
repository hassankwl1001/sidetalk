<?php if(\Session::has('success')): ?>
<div class="alert alert-success" style="text-align:center">
    <?php echo \Session::get('success'); ?>

</div>
<?php elseif(\Session::has('error')): ?>
<div class="alert alert-danger" style="text-align:center;">
    <?php echo \Session::get('error'); ?>

</div>
<?php endif; ?><?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/custom/inc/alerts.blade.php ENDPATH**/ ?>