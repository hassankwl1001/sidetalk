<div>
    <?php $__currentLoopData = $conversations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $conversation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <li class="messages-lists">
            <figure>
                <img class="img-size"
                     src="<?php echo e($conversation->profile_pic != null ? $profileUrl.$profile_pic : asset('assets/img').'/profile.png'); ?>"
                     style="height: 50px;width: auto;"   alt="">
            </figure>

            <div class="box-commented">
                <a href="<?php echo e(route('inbox',$conversation->sender == null ? $conversation->receiver->id : $conversation->sender->id)); ?>">

                    <div class="commented-description">
                        <strong
                            class="post_name"><?php echo e($conversation->sender == null ? $conversation->receiver->firstname." ". $conversation->receiver->lastname : $conversation->sender->firstname." ". $conversation->sender->lastname); ?></strong>
                    </div>
                    <?php if(isset($conversation->messages[0])): ?>
                        <span style="color: gray;font-size: 12px"><?php echo e($conversation->messages[0]->text); ?></span>
                    <?php endif; ?>


                </a>
            </div>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/livewire/conversation-list.blade.php ENDPATH**/ ?>