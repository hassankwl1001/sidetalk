
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('custom.inc.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('custom.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="jobdetail-page inner-padding-top">
    <div class="container default-container">
        <div class="row marginleftright">
            <div class="col-12 jobpost">
                <div class="job-company">
                    <div class="job-company-detail">
                        <img src="assets/img/alpha.jpg" alt="">
                        <div class="job-company-post">
                            <h2><?php echo e($post->jobs->job_title); ?></h2>
                            <p><?php echo e($post->jobs->location); ?></p>
                            <span>Posted <?php echo e($post->created_at->diffForHumans()); ?> | 895 views</span>
                            <?php if($post->userApplicant->isEmpty()): ?>
                                <a href="" id="quickSubmitJob" data-job="<?php echo e($post->id); ?>" class="btn__primary--large">Quick Submit</a>
                            <?php else: ?>
                                <a href="" class="btn__primary--large disabled">Applied</a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <hr/>
                    <div class="job-connections">
                        <div class="joblistsname">
                            <h4>Jobs</h4>
                            <ul>
                                <li><?php echo e($post->applicants_count); ?> applicants</li>
                                <li>Experience: <?php echo e($post->jobs->exp_from); ?> - <?php echo e($post->jobs->exp_to); ?></li>
                                <li>Skills: <?php echo e($post->jobs->skills); ?></li>
                            </ul>
                        </div>
                        <div class="joblistsname">
                            <h4>Company</h4>
                            <ul>
                                <li>11-50 employees</li>
                                <li><?php echo e($post->jobs->company); ?></li>
                            </ul>
                        </div>
                        <div class="joblistsname">
                            <h4>Salary</h4>
                            <ul>
                                <li><?php echo e($post->jobs->salary_from); ?> - <?php echo e($post->jobs->salary_to); ?></li>
                            </ul>
                        </div>
                    </div>
                    <hr/>
                    <div class="jobdescription">
                        <?php echo e($post->jobs->descriptiond); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('custom.inc.chatWidget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('custom.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/job/detail.blade.php ENDPATH**/ ?>