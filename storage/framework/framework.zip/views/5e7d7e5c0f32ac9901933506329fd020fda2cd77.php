<?php $__env->startSection('content'); ?>
<?php echo $__env->make('custom.inc.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('custom.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- MAIN CONTAINER -->
<div class="container">
    <!-- PROFILE -->
    <section id="profile">

    </section>
    <!-- LEFT ASIDE -->
    <div class="left-aside-wrapper" id="left-aside-wrapper">
        <aside class="left-aside" id="left-aside">
            <div class="profile-card" id="profile-card">
                <div id="background"></div>
                <div class="profile-info" id="profile-info">
                    <a href="<?php echo e(route('user.profile.show', auth()->id())); ?>"><img src="<?php echo e($urlProfile); ?>/<?php echo e(auth()->user()->profile_pic); ?>" alt="Profile picture" /></a>
                    <strong><?php echo e(auth()->user()->firstname); ?> <?php echo e(auth()->user()->lastname); ?></strong>
                    <?php if(isset($group->groupUser[0])): ?>
                        <small>Joined group: <?php echo e($group->groupUser[0]->pivot->created_at->diffForHumans()); ?></small>
                    <?php endif; ?>
                </div>
            </div>
            
        </aside>
    </div>
    <!-- MAIN -->
    <div id="main-wrapper">
        <main class="main-section" id="main-section">
            <div class="hashtag-page group-portion">
                <div class="group-bg">
                    <img src="<?php echo e($url); ?>/<?php echo e($group->banner); ?>" alt="" style="height:191px; width:100%; object-fit:cover;">
                </div>
                <div class="hash-image">
                    <img src="<?php echo e($url); ?>/<?php echo e($group->profile_pic); ?>" alt="group">
                </div>
                <div class="hash-page">
                    <h3><?php echo e($group->name); ?></h3>
                    <p><i class="fas fa-users"></i> Listed Group</p>
              </div>

              <?php if($group->groupUser->isEmpty()): ?>
                <input type="button" class="btn btn-success" id="join" data-group="<?php echo e($group->id); ?>" value="Join Group">
            <?php else: ?>
                <input type="button" class="btn btn-danger" id="leave" data-group="<?php echo e($group->id); ?>" value="Leave Group">
            <?php endif; ?>

            </div>
            <?php echo $__env->make('custom.inc.postsCard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article data-post="<?php echo e($post->id); ?>" class="post-article">
                    <!-- post header -->
                    <div class="post-author">
                        <a href="profile.html">
                            <div class="author-details">
                                <figure class="image-container">
                                    <?php if($post->user->profile_pic != null): ?>
                                        <img class="img-size" src="<?php echo e($urlProfile); ?>/<?php echo e($post->user->profile_pic); ?>" alt="">
                                    <?php else: ?>
                                        <img class="img-size" src="<?php echo e(asset('assets/img/profile.png')); ?>" alt="">
                                    <?php endif; ?>
                                </figure>
                                <div class="author-description">
                                    <div class="post-name-experience">
                                        <strong class="post-author-name"><?php echo e($post->user->firstname); ?> <?php echo e($post->user->lastname); ?></strong>
                                        <span>
                                            <span>&nbsp;·&nbsp;</span>
                                            3Y Exp</span>
                                        <span class="green_slot">J</span>
                                    </div>
                                    <span class="designation">
                                        <?php if($post->user->is_student == 1): ?> Student |<?php endif; ?>
                                        <?php echo e($post->user->current_position); ?>

                                    </span>
                                    <span class="time-ago"><?php echo e($post->created_at->diffForHumans()); ?></span>
                                </div>
                            </div>
                        </a>
                        <div class="consult-btn">
                            <button data-toggle="modal" data-target="#consultation"><img src="assets/img/camera.png" alt="">Consult</button>
                        </div>
                            <div class="vertical-icons">
                                <span class="fas fa-circle"></span>
                                <span class="fas fa-circle"></span>
                                <span class="fas fa-circle"></span>
                                <div class="notifications-signs">
                                    <ul>
                                        <li><a href="save-post.html"><i class="fas fa-save" aria-hidden="true"></i> Save <span class="dropdown-edit">Save for later</span></a></li>
                                        <li><a href=""><i class="fa fa-copy" aria-hidden="true"></i> Copy link to post</a></li>
                                        <li><a href=""><i class="fas fa-volume-mute" aria-hidden="true"></i> Mute Usman Rahim <span class="dropdown-edit">Stop seeing post for Usman</span></a></li>
                                        <li><a href=""><i class="fas fa-sign-out-alt" aria-hidden="true"></i> Leave this group<span class="dropdown-edit">Stop seeing post for this group</span></a></li>
                                        <li><a href="" data-toggle="modal" data-target="#report-post"><i class="fas fa-sign-out-alt" aria-hidden="true"></i> Report this post<span class="dropdown-edit">This post is offensive or account is hacked</span></a></li>
                                    </ul>
                                </div>
                            </div>
                    </div>
                    <!-- /post header -->

                    <!-- post body -->
                    <?php if($post->postType->name == 'Article'): ?>
                    <div class="post-data">
                        <h4 class="article-heading"><?php echo e($post->heading); ?></h4>
                        <p>
                            <?php echo e($post->description); ?>

                        </p>
                        <p class="post-translation">
                            <button><?php echo e($post->hashtags); ?></button>
                        </p>

                        <?php if(!$post->postMedia->isEmpty()): ?>
                            

                            
                            <iframe src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[0]->name); ?>" width="100%" height="500px"></iframe>
                        <?php endif; ?>

                    </div>
                    <?php elseif($post->postType->name == 'Photo' || $post->postType->name == 'Video'): ?>
                    <div class="post-data">
                        <p>
                            <?php echo e($post->description); ?>

                        </p>
                        <p class="post-translation">
                            <button><?php echo e($post->hashtags); ?></button>
                        </p>
                        <?php
                            $mediaCount = count($post->postMedia);
                        ?>
                        <?php if($mediaCount == 1): ?>
                            <?php if($post->postType->name == 'Photo'): ?>
                            <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[0]->name); ?>" class="postMediaContent" alt="Modal Image" />
                            <?php elseif($post->postType->name == 'Video'): ?>
                            <video style="width: 100%;" controls>
                                <source src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[0]->name); ?>" type="video/mp4">
                                <source src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[0]->name); ?>" type="video/mkv">
                                Your browser does not support HTML video.
                            </video>
                            <?php endif; ?>
                        <?php else: ?>

                            <?php if($mediaCount == 2): ?>
                            <div class="row">
                                <div class="col-md-6 imgShowColumn1">
                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[0]->name); ?>" class="postImage postMediaContent" alt="" />
                                </div>
                                <div class="col-md-6 imgShowColumn2">
                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[1]->name); ?>" class="postImage postMediaContent" alt="" />
                                </div>
                            </div>
                            <?php elseif($mediaCount == 3): ?>
                            <div class="row">
                                <div class="col-md-12 singleImage">
                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[0]->name); ?>" class="postMediaContent" alt="" />
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 imgShowColumn1">
                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[0]->name); ?>" class="postImage postMediaContent" alt="" />
                                </div>
                                <div class="col-md-6 imgShowColumn2">
                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[1]->name); ?>" class="postImage postMediaContent" alt="" />
                                </div>
                            </div>
                            <?php elseif($mediaCount == 4): ?>
                            <div class="row">
                                <div class="col-md-6 imgShowColumn1">
                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[0]->name); ?>" class="postImage postMediaContent" alt="" />
                                </div>
                                <div class="col-md-6 imgShowColumn2">
                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[1]->name); ?>" class="postImage postMediaContent" alt="" />
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 imgShowColumn3">
                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[2]->name); ?>" class="postImage postMediaContent" alt="" />
                                </div>
                                <div class="col-md-6 imgShowColumn4">
                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[3]->name); ?>" class="postImage postMediaContent" alt="" />
                                </div>
                            </div>
                            <?php elseif($mediaCount > 4): ?>
                            <div class="row">
                                <div class="col-md-12">
                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[0]->name); ?>" class="postMediaContent" alt="" />
                                </div>
                            </div>
                            <br>
                            <div class="row">
                            <div class="col-md-4 imgShowColumn1">
                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[1]->name); ?>" class="postMediaContent" alt="" />
                            </div>
                            <div class="col-md-4 imgShowColumn2 imgShowColumn3">
                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[2]->name); ?>" class="postMediaContent" alt="" />
                            </div>
                            <div class="col-md-4 imgShowColumn3" id="moreImagesbox">
                            <span id="moreImages">
                                    +<?php echo e($mediaCount - 3); ?>

                                </span>
                            </div>
                            </div>

                            <?php endif; ?> <!-- /count == 2 -->
                        <?php endif; ?> <!-- /count == 1 -->

                    </div>
                    <?php elseif($post->postType->name == 'Job'): ?>
                    <div class="job-post-data">
                        <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[0]->name); ?>" alt="" />
                        <div class="job-post-details">
                            <h2><?php echo e($post->jobs->job_title); ?></h2>
                            <p><?php echo e($post->jobs->description); ?></p>
                            <div class="job-post-descrption-detail">
                                <span><?php echo e($post->jobs->location); ?></span> .
                                <span><?php echo e($post->jobs->employeeType->name); ?></span> .
                                <span><?php echo e($post->jobs->salary_from); ?>-<?php echo e($post->jobs->salary_to); ?>k /month</span>
                                <a class="btn-primary" href="jobs-detail.html">Apply now</a>
                            </div>
                        </div>
                    </div>
                    <?php elseif($post->postType->name == 'Shared'): ?>
                    <div class="job-post-data">
                        

                            <!-- post header -->
                            <div class="post-author">
                                <a href="profile.html">
                                    <div class="author-details">
                                        <figure class="image-container">
                                            <?php if($post->shared->user->profile_pic != null): ?>
                                                <img class="img-size" src="<?php echo e($urlProfile); ?>/<?php echo e($post->shared->user->profile_pic); ?>" alt="">
                                            <?php else: ?>
                                                <img class="img-size" src="<?php echo e(asset('assets/img/profile.png')); ?>" alt="">
                                            <?php endif; ?>
                                        </figure>
                                        <div class="author-description">
                                            <div class="post-name-experience">
                                                <strong class="post-author-name"><?php echo e($post->shared->user->firstname); ?> <?php echo e($post->shared->user->lastname); ?></strong>
                                                <span>
                                                    <span>&nbsp;·&nbsp;</span>
                                                    3Y Exp</span>
                                                <span class="green_slot">J</span>
                                            </div>
                                            <span class="designation">
                                                <?php if($post->shared->user->is_student == 1): ?> Student |<?php endif; ?>
                                                <?php echo e($post->shared->user->current_position); ?>

                                            </span>
                                            <span class="time-ago"><?php echo e($post->shared->created_at->diffForHumans()); ?></span>
                                        </div>
                                    </div>
                                </a>
                            </div>
                            <!-- /post header -->

                            
                            <?php if($post->shared->postType->name == 'Article'): ?>
                            <div class="post-data">
                                <h4 class="article-heading"><?php echo e($post->shared->heading); ?></h4>
                                <p>
                                    <?php echo e($post->shared->description); ?>

                                </p>
                                <p class="post-translation">
                                    <button><?php echo e($post->hashtags); ?></button>
                                </p>

                                <?php if(!$post->shared->postMedia->isEmpty()): ?>
                                    

                                    
                                    <iframe src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[0]->name); ?>" width="100%" height="500px"></iframe>
                                <?php endif; ?>

                            </div>
                            <?php elseif($post->shared->postType->name == 'Photo' || $post->postType->name == 'Video'): ?>
                                <div class="post-data">
                                    <p>
                                        <?php echo e($post->shared->description); ?>

                                    </p>
                                    <p class="post-translation">
                                        <button><?php echo e($post->hashtags); ?></button>
                                    </p>
                                    <?php
                                        $mediaCount = count($post->shared->postMedia);
                                    ?>
                                    <?php if($mediaCount == 1): ?>
                                        <?php if($post->shared->postType->name == 'Photo'): ?>
                                        <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[0]->name); ?>" class="postMediaContent" alt="Modal Image" />
                                        <?php elseif($post->shared->postType->name == 'Video'): ?>
                                        <video style="width: 100%;" controls>
                                            <source src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[0]->name); ?>" type="video/mp4">
                                            <source src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[0]->name); ?>" type="video/mkv">
                                            Your browser does not support HTML video.
                                        </video>
                                        <?php endif; ?>
                                    <?php else: ?>

                                        <?php if($mediaCount == 2): ?>
                                        <div class="row">
                                            <div class="col-md-6 imgShowColumn1">
                                            <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[0]->name); ?>" class="postImage postMediaContent" alt="" />
                                            </div>
                                            <div class="col-md-6 imgShowColumn2">
                                            <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[1]->name); ?>" class="postImage postMediaContent" alt="" />
                                            </div>
                                        </div>
                                        <?php elseif($mediaCount == 3): ?>
                                        <div class="row">
                                            <div class="col-md-12 singleImage">
                                            <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[0]->name); ?>" class="postMediaContent" alt="" />
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6 imgShowColumn1">
                                            <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[0]->name); ?>" class="postImage postMediaContent" alt="" />
                                            </div>
                                            <div class="col-md-6 imgShowColumn2">
                                            <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[1]->name); ?>" class="postImage postMediaContent" alt="" />
                                            </div>
                                        </div>
                                        <?php elseif($mediaCount == 4): ?>
                                        <div class="row">
                                            <div class="col-md-6 imgShowColumn1">
                                            <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[0]->name); ?>" class="postImage postMediaContent" alt="" />
                                            </div>
                                            <div class="col-md-6 imgShowColumn2">
                                            <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[1]->name); ?>" class="postImage postMediaContent" alt="" />
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6 imgShowColumn3">
                                            <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[2]->name); ?>" class="postImage postMediaContent" alt="" />
                                            </div>
                                            <div class="col-md-6 imgShowColumn4">
                                            <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[3]->name); ?>" class="postImage postMediaContent" alt="" />
                                            </div>
                                        </div>
                                        <?php elseif($mediaCount > 4): ?>
                                        <div class="row">
                                            <div class="col-md-12">
                                            <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[0]->name); ?>" class="postMediaContent" alt="" />
                                            </div>
                                        </div>
                                        <br>
                                        <div class="row">
                                        <div class="col-md-4 imgShowColumn1">
                                            <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[1]->name); ?>" class="postMediaContent" alt="" />
                                        </div>
                                        <div class="col-md-4 imgShowColumn2 imgShowColumn3">
                                            <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[2]->name); ?>" class="postMediaContent" alt="" />
                                        </div>
                                        <div class="col-md-4 imgShowColumn3" id="moreImagesbox">
                                        <span id="moreImages">
                                                +<?php echo e($mediaCount - 3); ?>

                                            </span>
                                        </div>
                                        </div>

                                        <?php endif; ?> <!-- /count == 2 -->
                                    <?php endif; ?> <!-- /count == 1 -->

                                </div>
                            <?php elseif($post->shared->postType->name == 'Job'): ?>
                                <div class="job-post-data">
                                    <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[0]->name); ?>" alt="" />
                                    <div class="job-post-details">
                                        <h2><?php echo e($post->shared->jobs->job_title); ?></h2>
                                        <p><?php echo e($post->shared->jobs->description); ?></p>
                                        <div class="job-post-descrption-detail">
                                            <span><?php echo e($post->shared->jobs->location); ?></span> .
                                            <span><?php echo e($post->shared->jobs->employeeType->name); ?></span> .
                                            <span><?php echo e($post->shared->jobs->salary_from); ?>-<?php echo e($post->shared->jobs->salary_to); ?>k /month</span>
                                            <a class="btn-primary" href="jobs-detail.html">Apply now</a>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            
                    </div>
                    <?php endif; ?>
                    <!-- /post body -->

                    <!-- post interactions -->
                    <div class="post-interactions">
                        <div class="interactions-amount">
                            <div class="rating-stars">
                                <ul id="stars">
                                <li class="star 1 2 3 4 5 <?php if(!$post->rate->isEmpty() && $post->rate[0]->stars >= 1): ?> selected <?php endif; ?>" title="Poor" data-value="1"  data-rate="<?php if(!$post->rate->isEmpty()): ?> <?php echo e($post->rate[0]->id); ?> <?php endif; ?>">
                                    <i class="fa fa-star fa-fw"></i>
                                </li>
                                <li class="star 2 3 4 <?php if(!$post->rate->isEmpty() && $post->rate[0]->stars >= 2 ): ?> selected <?php endif; ?>" title="Fair" data-value="2" data-rate="<?php if(!$post->rate->isEmpty()): ?> <?php echo e($post->rate[0]->id); ?> <?php endif; ?>">
                                    <i class="fa fa-star fa-fw"></i>
                                </li>
                                <li class="star 3 4 5 <?php if(!$post->rate->isEmpty() && $post->rate[0]->stars >= 3): ?> selected <?php endif; ?>" title="Good" data-value="3" data-rate="<?php if(!$post->rate->isEmpty()): ?> <?php echo e($post->rate[0]->id); ?> <?php endif; ?>">
                                    <i class="fa fa-star fa-fw"></i>
                                </li>
                                <li class="star 4 5 <?php if(!$post->rate->isEmpty() && $post->rate[0]->stars >= 4): ?> selected <?php endif; ?>" title="Excellent" data-value="4" data-rate="<?php if(!$post->rate->isEmpty()): ?> <?php echo e($post->rate[0]->id); ?> <?php endif; ?>">
                                    <i class="fa fa-star fa-fw"></i>
                                </li>
                                <li class="star 5 <?php if(!$post->rate->isEmpty() && $post->rate[0]->stars == 5): ?> selected <?php endif; ?>" title="WOW!!!" data-value="5" data-rate="<?php if(!$post->rate->isEmpty()): ?> <?php echo e($post->rate[0]->id); ?> <?php endif; ?>">
                                    <i class="fa fa-star fa-fw"></i>
                                </li>
                                </ul>
                            </div>
                            <span class="amount-info"><?php echo e($post->view_count); ?> Views</span>
                        </div>
                        <div class="interactions-btns">
                        <?php if($post->rate->isEmpty()): ?>
                            <button>
                            <span class="counter ratePost"><i class="far fa-star"></i></span>
                            <span class="ratePost rateCounter">Rate [<?php echo e($post->rate_count); ?>]</span>
                            </button>
                        <?php else: ?>
                            <button>
                            <span class="counter ratePost"><i class="fa fa-star fa-clicked"></i></span>
                            <span class="ratePost rateCounter">Rate [<?php echo e($post->rate_count); ?>]</span>
                            </button>
                        <?php endif; ?>

                            <button>
                                <span class="counter"><img src="<?php echo e(asset('assets/img/Group8.png')); ?>" alt=""></span>
                                <span>Reflect [<?php echo e($post->reflections_count); ?>]</span>
                            </button>
                            <button class="repost-button">
                                <span class="counter"><img src="assets/img/Group5.png" alt=""></span>
                                <span>Repost [<?php echo e($post->post_shared_count); ?>]</span>
                            </button>
                            <button>
                                <span class="counter"><i class="fas fa-paper-plane"></i></span>
                                <span class="post-send">Send</span>
                            </button>
                        </div>
                    </div>
                    <!-- /post interactions -->

                    <!-- add new comment -->
                    <div class="post-input">
                        <div class="input-section">
                            <figure class="image-container">
                                <?php if(auth()->user()->profile_pic != null): ?>
                                <img class="img-size" src="<?php echo e($urlProfile); ?>/<?php echo e(auth()->user()->profile_pic); ?>" alt="">
                            <?php else: ?>
                                <img class="img-size" src="<?php echo e(asset('assets/img/profile.png')); ?>" alt="">
                            <?php endif; ?>
                            </figure>
                            <div class="input-portion">
                                <div>
                                    <input class="form-control reflection" type="text" placeholder="Add a reflection">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- /add new comment -->

                    <!-- previous comments -->
                    <div class="commented-groups">
                        <section>
                            <header>
                                <span class="heading-commented">Recent Reflections</span>
                                <span
                                    class="fas fa-angle-down"
                                    onclick="toggleProfileGroupList(this)"
                                ></span>
                            </header>
                            <ul class="group-list reflection-list">
                            <?php $__currentLoopData = $post->reflections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reflection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <div class="operations-user">
                                        <figure class="image-container">
                                            <?php if($reflection->user->profile_pic != null): ?>
                                            <img class="img-size" src="<?php echo e($urlProfile); ?>/<?php echo e($reflection->user->profile_pic); ?>" alt="">
                                            <?php else: ?>
                                            <img class="img-size" src="<?php echo e(asset('assets/img/profile.png')); ?>" alt="">
                                            <?php endif; ?>
                                        </figure>
                                        <div class="box-commented">
                                            <div class="commented-description">
                                                <strong class="post_name"><?php echo e($reflection->user->firstname); ?> <?php echo e($reflection->user->lastname); ?></strong>
                                                <span class="post_designation">
                                                    <span>&nbsp;·&nbsp;</span>
                                                    5Y Exp
                                                </span>
                                            </div>
                                            <span class="designation"><?php echo e($reflection->user->current_position); ?></span>
                                            <span class="comment-user"><?php echo e($reflection->reflection); ?></span>
                                        </div>
                                    </div>



                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <div class="load-more">
                                <a href="" data-value="0">Load more reflections</a>
                            </div>
                        </section>
                    </div>
                    <!-- /previous comments -->
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <p>No post found</p>
            <?php endif; ?>
        </main>
    </div>
    <!-- RIGHT ASIDE -->
    <aside class="right-aside" id="right-aside">
        <div class="rec-section" id="rec-section">
            <div class="right-sidebar">
                <header>
                    <span><?php echo e($group->members_count); ?> members</span>
                </header>
                <div class="top-right-bar">
                    <p>Members already joined this group</p>
                    <div class="top-right-bar-detail">
                        <?php $__currentLoopData = $group->members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img class="mb-8" src="<?php echo e($urlProfile); ?>/<?php echo e($member->profile_pic); ?>" style="border-radius: 50%;" alt="" >
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
                <a href="#">See All</a>
            </div>
        </div>
        <div class="job-section" id="job-section">
            <div class="right-sidebar">
                <header>
                    <span>About this group</span>
                </header>
                <div class="top-right-bar">
                    <div class="top-right-bar-detail">
                        <div class="top-right-bar-description">
                           <?php echo e($group->about); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="rec-section" id="rec-section">
            <div class="right-sidebar">
                <header>
                    <span>Admin</span>
                </header>
                <div class="top-right-bar group-admin">
                    <?php $__currentLoopData = $group->groupAdmins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="top-right-bar-detail">
                            <img src="<?php echo e($urlProfile); ?>/<?php echo e($admin->profile_pic); ?>" style="border-radius: 50%;" alt="">
                            <div class="top-right-bar-description">
                                <h4><?php echo e($admin->firstname); ?> <?php echo e($admin->lastname); ?></h4>
                                <small>Admin</small>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
        <div class="advertisement-section" id="advertisement-section">
            <div class="advertisement-portion">
                <header>
                    <span>Advertisement</span>
                </header>
                <div class="advertisement-space">
                    <figure>
                        <img src="assets/img/advertisement.png" alt="">
                    </figure>
                </div>
            </div>
        </div>
    </aside>
</div>

<?php echo $__env->make('custom.inc.postsCardModels', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('custom.inc.chatWidget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('custom.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/group/groupDetail.blade.php ENDPATH**/ ?>