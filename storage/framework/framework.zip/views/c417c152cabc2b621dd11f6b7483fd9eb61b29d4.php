<section class="chatbox js-chatbox my-5">
    <div class="chatbox__header">
      <h3 class="chatbox__header-cta-text">
          <span class="chatbox__header-cta-icon">
              <figure class="image-container">
                  <img class="img-size" src="<?php echo e($profile_pic); ?>" alt="">
              </figure>
          </span>
      Chat Box</h3>
      <button class="js-chatbox-toggle chatbox__header-cta-btn u-btn">






          <i class="fas fa-chevron-up"></i>
      </button>
    </div>
    <div class="js-chatbox-display chatbox__display">






        <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('conversation-list')->html();
} elseif ($_instance->childHasBeenRendered('RTx6ruC')) {
    $componentId = $_instance->getRenderedChildComponentId('RTx6ruC');
    $componentTag = $_instance->getRenderedChildComponentTagName('RTx6ruC');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('RTx6ruC');
} else {
    $response = \Livewire\Livewire::mount('conversation-list');
    $html = $response->html();
    $_instance->logRenderedChild('RTx6ruC', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
    </div>




  </section>
<?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/custom/inc/chatWidget.blade.php ENDPATH**/ ?>