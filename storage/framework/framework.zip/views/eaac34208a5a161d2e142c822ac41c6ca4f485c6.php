<div class="share-box" id="share-box">

    <form >
      
    <div class="profile-box">

        <?php if(auth()->user()->profile_pic != null): ?>
             <img src="<?php echo e($urlProfile); ?>/<?php echo e(auth()->user()->profile_pic); ?>" alt="Profile picture" />
        <?php else: ?>
             <img src="<?php echo e(asset('assets/img/profile.png')); ?>" alt="Profile picture" />
        <?php endif; ?>
            <div class="search-profile">
            <input class="form-control" value="<?php echo e(request('discover')); ?>" type="text" id="discover" name="discover" required placeholder="discover...">
        </div>
    </div>
    <div class="text-right">
        <div class="right">
            <button type="button" class="postButton border-0 border-none p-1 discover_posts1">
                Discover
            </button>
        </div>
    </div>

    </form>

</div>
<?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/custom/inc/searchCard.blade.php ENDPATH**/ ?>