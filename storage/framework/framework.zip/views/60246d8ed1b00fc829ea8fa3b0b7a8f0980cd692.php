<div class="modal fade" id="upload-photo" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title" id="exampleModalLongTitle">Post a photo</h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="content">
                    <form class="login__form popup__form" action="<?php echo e(route('post.store')); ?>" method="post"
                          enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="upload-photo-profile">
                            <div class="operations-user">
                                <img class="img-size" src="<?php echo e($profile_pic); ?>" alt="">
                                <div class="box-commented">
                                    <div class="commented-description">
                                        <strong
                                            class="post_name"><?php echo e(auth()->user()->firstname); ?> <?php echo e(auth()->user()->lastname); ?></strong>
                                    </div>
                                    <select class="postPrivacy" name="privacy">
                                        <option value="Public" selected> &#xf0ac; &nbsp;&nbsp;<span
                                                style="font-family: 'Lato', sans-serif !important;">Public</span>
                                        </option>
                                        <option value="Friends">&#xf0c0; &nbsp;Friends</option>
                                        <option value="Private">&#xf406; &nbsp; &nbsp;Private</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="form__input--floating border-none">
                            <textarea id="input--text" placeholder="Add Text" name="description"></textarea>
                        </div>
                        <div class="form__input--floating photo_upload">
                            <input type="file" multiple id="gallery-photo-add" name="file[]" class="myPdf"/>
                            <div class="gallery_images"></div>

                            <canvas id="pdfViewer" style="width:0%;"></canvas>

                        </div>
                        <div class="form__input--floating Add_hashtag">
                            <input type="text" id="input--text" placeholder="Add HashTags" name="hashtags"/>
                        </div>
                        <input type="hidden" name="post_type" value="Photo">
                        <?php if(Route::current()->getName() == 'page.show'): ?>
                            <input type="hidden" name="page_id" value="<?php echo e($page->id); ?>">
                        <?php elseif(Route::current()->getName() == 'group.detail'): ?>
                            <input type="hidden" name="group_id" value="<?php echo e($group->id); ?>">
                        <?php endif; ?>
                        <div
                            class="login__form_icons login__form_action_container login__form_action_container--multiple-actions">
                            <button class="btn__secondary--large from__button--floating" data-dismiss="modal"
                                    aria-label="">Back
                            </button>
                            <button class="btn__primary--large from__button--floating" type="submit" aria-label="">
                                Post
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- post Videos -->

<div class="modal fade" id="upload-video" tabindex="-1" role="dialog" style="z-index: 1400;"
     aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title" id="exampleModalLongTitle">Post a Video</h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="content">
                    <form class="login__form popup__form" action="<?php echo e(route('post.store')); ?>" method="post"
                          enctype="multipart/form-data" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="upload-photo-profile">
                            <div class="operations-user">
                                <img class="img-size" src="<?php echo e($profile_pic); ?>" alt="">
                                <div class="box-commented">
                                    <div class="commented-description">
                                        <strong
                                            class="post_name"><?php echo e(auth()->user()->firstname); ?> <?php echo e(auth()->user()->lastname); ?></strong>
                                    </div>
                                    <select class="postPrivacy" name="privacy">
                                        <option value="Public" selected> &#xf0ac; &nbsp;&nbsp;<span
                                                style="font-family: 'Lato', sans-serif !important;">Public</span>
                                        </option>
                                        <option value="Friends">&#xf0c0; &nbsp;Friends</option>
                                        <option value="Private">&#xf406; &nbsp; &nbsp;Private</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="form__input--floating border-none">
                            <textarea id="input--text" placeholder="Add Text" name="description"></textarea>
                        </div>
                        <div class="form__input--floating photo_upload">
                            <label for="label__video" class="form__label--floating">Select video to share</label>
                            <input type="file" id="label__video" name="file[]" accept="video/*" style="display: none;"/>
                            <video id="video" controls></video>
                        </div>
                        <div class="form__input--floating Add_hashtag">
                            <input type="text" id="input--text" placeholder="Add HashTags" name="hashtags"/>
                        </div>
                        <input type="hidden" name="post_type" value="Video">
                        <?php if(Route::current()->getName() == 'page.show'): ?>
                            <input type="hidden" name="page_id" value="<?php echo e($page->id); ?>">
                        <?php elseif(Route::current()->getName() == 'group.detail'): ?>
                            <input type="hidden" name="group_id" value="<?php echo e($group->id); ?>">
                        <?php endif; ?>
                        <div
                            class="login__form_icons login__form_action_container login__form_action_container--multiple-actions">
                            <a href="javascript:void(0)" class="btn__secondary--large from__button--floating"
                               data-toggle="modal" data-target="#myModal2" aria-label="">Back</a>
                            <button class="btn__primary--large from__button--floating">Post</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- post Draft -->
<div class="modal fade" id="myModal2" tabindex="-1" role="dialog" style="z-index: 1600;">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title" id="exampleModalLongTitle">Discard Draft</h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="content">
                    <form class="login__form popup__form" action="" method="post">
                        <p>You haven’t finished your post yet. Are you sure you want to leave and discard your
                            draft?</p>
                        <div
                            class="login__form_icons login__form_action_container login__form_action_container--multiple-actions">
                            <button class="btn__secondary--large from__button--floating" aria-label="">Back</button>
                            <button class="btn__primary--large from__button--floating" data-dismiss="modal"
                                    aria-label="">Discard
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- post a job -->
<div class="modal fade" id="create-job" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title" id="exampleModalLongTitle">Create a job</h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="content">
                    <form class="login__form popup__form" action="<?php echo e(route('post.store')); ?>" enctype="multipart/form-data"
                          method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form__input--floating">
                            <label class="form__label--floating" id="label--job">Job Title <span>*</span></label>
                            <input type="text" id="input--job" placeholder="Enter a job title" name="job_title"
                                   required/>
                        </div>

                        <div class="form__input--floating">
                            <label class="form__label--floating" id="label--job">Job Poster <span>*</span></label>
                            <input type="file" name="file" class="form-control" required>
                        </div>

                        <div class="form__input--floating">
                            <label class="form__label--floating" id="label--job">Company <span>*</span></label>
                            <input type="text" id="input--company" placeholder="Enter a Company Name" required
                                   name="company"/>
                        </div>

                        <div class="form__input--floating">
                            <label class="form__label--floating" id="label--location">Location <span>*</span></label>
                            <input type="text" id="input--location" placeholder="Enter a location" required
                                   name="location"/>
                        </div>
                        <div class="form__input--floating">
                            <label class="form__label--floating" id="label--job">Skills <span>*</span></label>
                            <input type="text" id="input--skills" placeholder="Enter a job Skills" required
                                   name="skills"/>
                        </div>

                        <div class="form__input--floating">
                            <label class="form__label--floating" id="label--qualification">Qualification <span>*</span></label>
                            <input type="text" id="input--qualification" required placeholder="Enter a qualification"
                                   name="qualification"/>
                        </div>
                        <div class="form__input--floating">
                            <div class="form__label--dropdown">
                                <label class="form__label--floating" id="label--experience">Experience</label>
                                <select class="mr-0" name="exp_from" id="input--experience-from" required>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                    <option value="9">9</option>
                                    <option value="10">10</option>
                                </select>
                                <span>to</span>
                                <select class="mr-0" name="exp_to" id="input--experience-to" required>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                    <option value="9">9</option>
                                    <option value="10">10</option>
                                </select>
                            </div>
                        </div>
                        <div class="form__input--floating">
                            <label class="form__label--floating" id="label--employment">Employment Type
                                <span>*</span></label>
                            <div class="form__label--dropdown">
                                <select class="mr-0" name="employee_type_id" id="input--employment" required>
                                    <option value="1">Full-time and Part-time employees</option>
                                    <option value="2">Casual Employees</option>
                                    <option value="3">Fixed term and contract</option>
                                    <option value="4">Apprentices and trainees</option>
                                    <option value="5">Commission and piece rate employees</option>
                                </select>
                            </div>
                        </div>
                        <div class="form__input--floating">
                            <div class="form__label--dropdown">
                                <label class="form__label--floating" id="label--salary-from">Salary</label>
                                <select class="mr-0" name="salary_from" id="input--salary-from" required>
                                    <option value="10,000">10,000</option>
                                    <option value="20,000">20,000</option>
                                    <option value="30,000">30,000</option>
                                    <option value="40,000">40,000</option>
                                    <option value="50,000">50,000</option>
                                    <option value="60,000">60,000</option>
                                    <option value="70,000">70,000</option>
                                    <option value="80,000">80,000</option>
                                    <option value="90,000">90,000</option>
                                    <option value="100,000">100,000</option>
                                </select>
                                <span>to</span>
                                <select class="mr-0" name="salary_to" id="input--salary-to" required>
                                    <option value="100,000">100,000</option>
                                    <option value="200,000">200,000</option>
                                    <option value="300,000">300,000</option>
                                    <option value="400,000">400,000</option>
                                    <option value="500,000">500,000</option>
                                    <option value="600,000">600,000</option>
                                    <option value="700,000">700,000</option>
                                    <option value="800,000">800,000</option>
                                    <option value="900,000">900,000</option>
                                    <option value="1,000,000">1,000,000</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="form__input--floating">
                            <label class="form__label--floating" id="label--job-description">Job Description
                                <span>*</span></label>
                            <textarea id="input--description" placeholder="Explain what skills you are looking for"
                                      required name="description"></textarea>
                        </div>
                        <input type="hidden" name="post_type" value="Job">
                        <input type="hidden" name="privacy" value="Public">
                        <?php if(Route::current()->getName() == 'page.show'): ?>
                            <input type="hidden" name="page_id" value="<?php echo e($page->id); ?>">
                        <?php elseif(Route::current()->getName() == 'group.detail'): ?>
                            <input type="hidden" name="group_id" value="<?php echo e($group->id); ?>">
                        <?php endif; ?>
                        <div class="login__form_action_container login__form_action_container--multiple-actions">
                            <button class="btn__secondary--large from__button--floating" data-dismiss="modal"
                                    aria-label="">Back
                            </button>
                            <button class="btn__primary--large from__button--floating" type="submit" aria-label="">
                                Post
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- post an Article -->
<div class="modal fade" id="write-article" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title" id="exampleModalLongTitle">Write Article</h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="content">
                    <form class="login__form popup__form" action="<?php echo e(route('post.store')); ?>" method="post"
                          enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form__input--floating">
                            <label class="form__label--floating" id="label--heading">Heading <span>*</span></label>
                            <input type="text" id="input--heading" placeholder="Enter your heading" name="heading"/>
                        </div>
                        <div class="form__input--floating">
                            <label class="form__label--floating" id="label--description">Description
                                <span>*</span></label>
                            <textarea id="input--description" placeholder="Write some description"
                                      name="description"></textarea>
                        </div>
                        <div class="form__input--floating upload_pdf">
                            <label for="label__photo" class="form__label--floating">Select PDF File</label>
                            <input id="label__photo" type="file" name="file[]"
                                   accept="application/pdf,application/vnd.ms-excel"/>
                        </div>
                        <div class="form__input--floating Add_hashtag">
                            <input type="text" id="input--text" placeholder="Add HashTags" name="hashtags"/>
                        </div>
                        <div class="login__form_action_container login__form_action_container--multiple-actions">
                            <button class="btn__secondary--large from__button--floating" data-dismiss="modal"
                                    aria-label="">Cancel
                            </button>
                            <button class="btn__primary--large from__button--floating" type="submit" aria-label="">
                                Submit
                            </button>
                        </div>
                        <input type="hidden" name="privacy" value="Public">
                        <input type="hidden" name="post_type" value="Article">
                        <?php if(Route::current()->getName() == 'page.show'): ?>
                            <input type="hidden" name="page_id" value="<?php echo e($page->id); ?>">
                        <?php elseif(Route::current()->getName() == 'group.detail'): ?>
                            <input type="hidden" name="group_id" value="<?php echo e($group->id); ?>">
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Post Repost -->
<div class="modal fade" id="repost" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title" id="exampleModalLongTitle">Repost</h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="content">
                    <form class="login__form popup__form" action="<?php echo e(route('post.store')); ?>" method="post"
                          enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="upload-photo-profile">
                            <div class="operations-user">
                                <img class="img-size" src="<?php echo e($profile_pic); ?>" alt="">
                                <div class="box-commented">
                                    <div class="commented-description">
                                        <strong
                                            class="post_name"><?php echo e(auth()->user()->firstname); ?> <?php echo e(auth()->user()->lastname); ?></strong>
                                    </div>
                                    <select class="postPrivacy" id="repostPostPrivacy" name="privacy">
                                        <option value="Public" selected> &#xf0ac; &nbsp;&nbsp;<span
                                                style="font-family: 'Lato', sans-serif !important;">Public</span>
                                        </option>
                                        <option value="Friends">&#xf0c0; &nbsp;Friends</option>
                                        <option value="Private">&#xf406; &nbsp; &nbsp;Private</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="form__input--floating">
                            <label class="form__label--floating" id="label--description">Description
                                <span>*</span></label>
                            <textarea id="repost_description" placeholder="Write some description"
                                      name="description"></textarea>
                        </div>
                        <input type="hidden" id="repost_post" value="">
                        <?php if(Route::current()->getName() == 'page.show'): ?>
                            <input type="hidden" name="page_id" value="<?php echo e($page->id); ?>">
                        <?php elseif(Route::current()->getName() == 'group.detail'): ?>
                            <input type="hidden" name="group_id" value="<?php echo e($group->id); ?>">
                        <?php endif; ?>
                        <div class="login__form_action_container login__form_action_container--multiple-actions">
                            <button class="btn__secondary--large from__button--floating" data-dismiss="modal"
                                    aria-label="">Cancel
                            </button>
                            <button button class="btn__primary--large from__button--floating" id="repost-post"
                                    aria-label="">Repost
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="sendPost" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h2 class="modal-title" id="exampleModalLongTitle">Send with Friends</h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="content">
                    <ul class="sub-menu" id="friendList">

                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>





<?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/custom/inc/postsCardModels.blade.php ENDPATH**/ ?>