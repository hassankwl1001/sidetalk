   <!-- LOADING PAGE -->
   <div class="loading-page" id="loading-page">
    <div class="loading-section">
        <img src="assets/img/skilled.png" alt="" />
        <div class="dot-loader" id="dot-loader">
            <div class="lds-ellipsis">
                <div></div>
                <div></div>
                <div></div>
                <div></div>
            </div>
        </div>
    </div>
</div><?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/custom/inc/loading.blade.php ENDPATH**/ ?>