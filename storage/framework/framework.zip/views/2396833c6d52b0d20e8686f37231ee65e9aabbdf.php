<?php $__env->startSection('content'); ?>

    <style>
        .field-icon {
            float: right;
            margin-left: -25px;
            margin-top: -28px;
            margin-right: 6px;
            position: relative;
            z-index: 2;
        }
    </style>
    <main class="signup__content">
        <div class="header__logo">
            <img src="<?php echo e(asset('assets/img/skilled.png')); ?>" alt="logo">
        </div>
        <!-- <div class="header__content">
          <h1 class="header__content__heading">Sign Up</h1>
        </div> -->
        <?php if(Session::has('status')): ?>
            <p class="alert alert-info"><?php echo e(Session::get('status')); ?></p>
        <?php endif; ?>
        <?php if(count($errors) > 0): ?>
            <p class="alert alert-danger"><?php echo e($errors); ?></p>
        <?php endif; ?>



        <form id="signform" class="login__form"  action="<?php echo e(route('password.email')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <fieldset>
                <h2 class="fs-title">Forget Password</h2>
                <h3 class="fs-subtitle">Give your Registered Email</h3>
                <div class="form__input--floating">
                    <label class="form__label--floating" id="label--email">Email</label>
                    <input id="email" value="<?php echo e(old('email')); ?>" type="email" placeholder="abx@xyz.com" name="email" required>
                    <small style="color: red" id="emailvalidation"></small>
                </div>

                <div class="login__form_action_container login__form_action_container--multiple-actions">
                    <input type="submit" class="continue_button btn__primary--large from__button--floating" aria-label="Sign Up" value="Email Password Reset Link" />
                </div>

                <div class="footer-app-content-actions">


                    <div class="login__para">
                        <p>Please read our <a href="<?php echo e(route('policy')); ?>">privacy policy</a> & <a href="<?php echo e(route('terms')); ?>">terms of use</a> here</p>
                    </div>
                    <div class="Signin__class">
                        <p>Create account on <img src="<?php echo e(asset('assets/img/skilled.png')); ?>" alt="">?<a href="<?php echo e(route('register')); ?>">Sign Up</a></p>
                    </div>
                </div>
            </fieldset>
        </form>

    </main>
    <script>
        $(document).ready(function () {
            $(document).on('keypress keydown','#email',function () {
                if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(signform.email.value))
                {
                    document.getElementById('emailvalidation').innerHTML=''
                    return
                }
                document.getElementById('emailvalidation').innerHTML='please enter valid email address'
                // alert("You have entered an invalid email address!")
                return
            })
        })

    </script>
<?php $__env->stopSection(); ?>





<?php echo $__env->make('custom.layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/auth/forgot-password.blade.php ENDPATH**/ ?>