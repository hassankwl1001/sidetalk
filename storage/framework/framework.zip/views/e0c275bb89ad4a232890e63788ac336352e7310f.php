<?php $__env->startSection('content'); ?>
<?php echo $__env->make('custom.inc.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('custom.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="business-page inner-padding-top">
    <div class="container default-container">
        <div class="row marginleftright">
            <div class="col-12 paddingleftright">
                <div class="section-heading">
                    <h2>Create a Business Page</h2>
                    <p>Connect with clients, employees, and skilledtalk community. To get started, choose a page type.</p>
                </div>
                <ul>
                    <li>
                        <a href="<?php echo e(route('page.setup', 1)); ?>">
                            <div class="business-page-lists">
                                <i class="fas fa-igloo"></i>
                                <h4>Small Business</h4>
                                <p>Fewer than 200 employees</p>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('page.setup', 2)); ?>">
                            <div class="business-page-lists">
                                <i class="fas fa-hotel"></i>
                                <h4>Medium to large business</h4>
                                <p>More than 200 employees</p>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('page.setup', 3)); ?>">
                            <div class="business-page-lists">
                                <i class="fas fa-house-damage"></i>
                                <h4>Showcase page</h4>
                                <p>Sub-pages associated with an existing page</p>
                            </div>
                        </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('page.setup', 4)); ?>">
                            <div class="business-page-lists">
                                <i class="fas fa-university"></i>
                                <h4>Educational institution</h4>
                                <p>Schools and universities</p>
                            </div>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</section>



<?php echo $__env->make('custom.inc.chatWidget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('custom.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/page/pageType.blade.php ENDPATH**/ ?>