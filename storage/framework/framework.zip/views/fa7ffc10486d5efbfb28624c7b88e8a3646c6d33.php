<footer class="footer-content">
    <div class="footer-content-copyright">
        <ul>
            <li><img src="<?php echo e(asset('assets/img/ftr-logo.png')); ?>" alt="ftr-logo"> © 2020</li>
            <li><a href="<?php echo e(route('about')); ?>">About</a></li>
            <li><a href="<?php echo e(route('disclaimer')); ?>">Disclaimer</a></li>
            <li><a href="<?php echo e(route('policy')); ?>">Privacy Policy</a></li>
            <li><a href="<?php echo e(route('cookie.policy')); ?>">Cookie Policy</a></li>
            <li><a href="<?php echo e(route('terms')); ?>">Terms of use</a></li>
        </ul>
    </div>
</footer>
<?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/custom/inc/guestFooter.blade.php ENDPATH**/ ?>