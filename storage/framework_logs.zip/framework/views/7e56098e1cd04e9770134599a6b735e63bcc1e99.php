<?php $__env->startSection('content'); ?>

    <style>
        .field-icon {
            float: right;
            margin-left: -25px;
            margin-top: -28px;
            margin-right: 6px;
            position: relative;
            z-index: 2;
        }
    </style>
    <main class="signup__content">
        <div class="header__logo">
            <img src="<?php echo e(asset('assets/img/skilled.png')); ?>" alt="logo">
        </div>
        <!-- <div class="header__content">
          <h1 class="header__content__heading">Sign Up</h1>
        </div> -->
        <?php if(Session::has('status')): ?>
            <p class="alert alert-info"><?php echo e(Session::get('status')); ?></p>
        <?php endif; ?>
         <?php if(count($errors) > 0): ?>
            <p class="alert alert-danger"><?php echo e($errors); ?></p>
        <?php endif; ?>
        <form id="signform" class="login__form"  action="<?php echo e(route('password.update')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <!-- Password Reset Token -->
            <input type="hidden" name="token" value="<?php echo e($request->route('token')); ?>">

            <fieldset>
                <h2 class="fs-title">Reset Password</h2>

                <div class="form__input--floating">
                    <label class="form__label--floating" id="label--email">Email</label>
                    <input id="email" value="<?php echo e($request->email); ?>" type="email" placeholder="abx@xyz.com" name="email" required>
                    <small style="color: red" id="emailvalidation"></small>
                </div>
                <div class="form__input--floating">
                    <label class="form__label--floating" id="label--password">Password</label>

                    <input id="password-field"  type="password"  placeholder="******" name="password" required>
                    <span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>
                </div>
                <div class="form__input--floating">
                    <label class="form__label--floating" id="label--password">Password Confirmation</label>

                    <input id="password-fields"  type="password"  placeholder="******" name="password_confirmation" required>
                    <span toggle="#password-fields" class="fa fa-fw fa-eye field-icon toggle-passwords"></span>
                </div>
                <div class="login__form_action_container login__form_action_container--multiple-actions">
                    <input type="submit" class="continue_button btn__primary--large from__button--floating" aria-label="Sign Up" value="Reset Password" />
                </div>

                <div class="footer-app-content-actions">


                    <div class="login__para">
                        <p>Please read our <a href="<?php echo e(route('policy')); ?>">privacy policy</a> & <a href="<?php echo e(route('terms')); ?>">terms of use</a> here</p>
                    </div>
                    <div class="Signin__class">
                        <p>Create account on <img src="<?php echo e(asset('assets/img/skilled.png')); ?>" alt="">?<a href="<?php echo e(route('register')); ?>">Sign Up</a></p>
                    </div>
                </div>
            </fieldset>
        </form>

    </main>
    <script>
        $(document).ready(function () {
            $(".toggle-password").click(function() {

                $(this).toggleClass("fa-eye fa-eye-slash");
                var input = $($(this).attr("toggle"));
                if (input.attr("type") == "password") {
                    input.attr("type", "text");
                } else {
                    input.attr("type", "password");
                }
            });
            $(".toggle-passwords").click(function() {

                $(this).toggleClass("fa-eye fa-eye-slash");
                var input = $($(this).attr("toggle"));
                if (input.attr("type") == "password") {
                    input.attr("type", "text");
                } else {
                    input.attr("type", "password");
                }
            });
        })

    </script>
<?php $__env->stopSection(); ?>






<?php echo $__env->make('custom.layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/auth/reset-password.blade.php ENDPATH**/ ?>