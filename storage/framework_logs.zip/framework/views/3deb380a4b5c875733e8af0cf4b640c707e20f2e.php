<?php $__env->startSection('content'); ?>

    <style>
        .field-icon {
            float: right;
            margin-left: -25px;
            margin-top: -28px;
            margin-right: 6px;
            position: relative;
            z-index: 2;
        }
    </style>
    <main class="signup__content">
        <div class="header__logo">
            <img src="<?php echo e(asset('assets/img/skilled.png')); ?>" alt="logo">
        </div>







        <?php if(session('status') == 'verification-link-sent'): ?>
            <div class="mb-4 font-medium text-sm text-green-600 alert alert-info">
                <?php echo e(__('A new verification link has been sent to the email address you provided during registration.')); ?>

            </div>
        <?php endif; ?>























        <form id="signform" class="login__form"  action="<?php echo e(route('verification.send')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <fieldset>
                <div class="form__input--floating">
                    <label class="form__label--floating" id="label--email">Please Verify Email</label>
                </div>

                <input type="submit" class=" btn__primary--large from__button--floating px-1" value="Resend Email">
            </fieldset>
        </form>

    </main>

<?php $__env->stopSection(); ?>





<?php echo $__env->make('custom.layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/auth/verify-email.blade.php ENDPATH**/ ?>