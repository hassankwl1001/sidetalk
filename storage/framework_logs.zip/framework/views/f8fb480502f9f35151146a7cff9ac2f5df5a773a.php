<?php $__env->startSection('content'); ?>
<?php echo $__env->make('custom.inc.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('custom.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div style="padding-top:100px;">
    <div class="balance">
        <span class="usdEarned">$ <?php echo e($usdEarned); ?></span>
        <p>Your Available Balance</p>
        <a href="<?php echo e(route('withdrawal')); ?>" class="btn btn-info">Withdraw</a>
    </div>




    <div class="card-header">
        <i class="fa fa-table"></i> Consultations
    </div>

    <div class="table-responsive" >
        <table class="table">
        <thead>
            <tr>
            <th scope="col">#</th>
            <th scope="col">Profile</th>
            <th scope="col">date</th>
            <th scope="col">time</th>
            <th scope="col">type</th>
            <th scope="col">description</th>
            <th scope="col">Verify</th>
            <th scope="col">Price</th>
            <th scope="col">Join</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $engagement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $engagement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                if($engagement->consultFrom->id == auth()->id()){
                    $user = $engagement->consultWith;
                }else{
                    $user = $engagement->consultFrom;
                }

            ?>
            <tr>
                <th scope="row"><?php echo e($loop->iteration); ?></th>
                <td><img src="<?php if($user->profile_pic !=null): ?><?php echo e($profileUrl); ?>/<?php echo e($user->profile_pic); ?> <?php else: ?> <?php echo e(asset('assets/img/profile.png')); ?> <?php endif; ?>" class="img-size"> <a href="<?php echo e(route('user.profile.show', $user->id)); ?>"><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></a></td>
                <td><?php echo e($engagement->date); ?></td>
                <td><?php echo e($engagement->time); ?></td>
                <td><?php echo e($engagement->consult_type); ?></td>
                <td><?php echo e($engagement->desc); ?></td>
                <td> <?php if($engagement->is_approved == 0): ?>
                            <?php if($engagement->consult_from == auth()->id()): ?>
                                <a href="<?php echo e(route('engagements.verify',$engagement->id)); ?>" class="btn btn-success">Verify</a>
                            <?php else: ?>
                                <a href="#" class="btn btn-success disabled">Pending</a>
                            <?php endif; ?>
                        <?php elseif($engagement->is_approved == 1): ?>
                            <a href="#" class="btn btn-success disabled">Approved</a>
                        <?php endif; ?>
                </td>
                <td>$ <?php echo e($engagement->actual_payment_earned); ?></td>
                <td> <a href="<?php echo e(route('user.calling',$engagement->meeting_id)); ?>" class="btn btn-primary <?php if($engagement->is_accepted != 1): ?> disabled <?php endif; ?>">Join</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            No Consultation
            <?php endif; ?>

        </tbody>
        </table>
    </div>
</div>

<?php echo $__env->make('custom.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/wallet/wallet.blade.php ENDPATH**/ ?>