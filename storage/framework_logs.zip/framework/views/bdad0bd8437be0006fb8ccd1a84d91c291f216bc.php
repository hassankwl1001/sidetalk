<?php echo e($slot); ?>

<?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>