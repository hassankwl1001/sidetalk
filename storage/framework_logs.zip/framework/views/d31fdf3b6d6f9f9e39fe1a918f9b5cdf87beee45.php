<?php $__env->startSection('content'); ?>
    <style>
        .field-icon {
            float: right;
            margin-left: -25px;
            margin-top: -28px;
            margin-right: 6px;
            position: relative;
            z-index: 2;
        }
    </style>
    <main class="signup__content">
        <div class="header__logo">
            <img src="<?php echo e(asset('assets/img/skilled.png')); ?>" alt="logo">
        </div>
        <!-- <div class="header__content">
          <h1 class="header__content__heading">Sign Up</h1>
        </div> -->
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'components.auth-validation-errors','data' => ['class' => 'mb-4','style' => 'color:red','errors' => $errors]]); ?>
<?php $component->withName('auth-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4','style' => 'color:red','errors' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($errors)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
        <form id="signform" class="login__form" action="<?php echo e(route('register')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <fieldset style="position: relative">
                <div class="pageNumber" style="position: absolute; font-size:12px">1 / 4</div>
                <h2 class="fs-title">SignUp Detail</h2>
                <h3 class="fs-subtitle">Give your login credentails</h3>
                <div class="form__input--floating">
                    <label class="form__label--floating" id="label--email">Email</label>
                    <input id="input--email" type="email" value="<?php echo e(old('email')); ?>" placeholder="abx@xyz.com"
                           name="email">
                    <small style="color: red" id="emailvalidation"></small>

                </div>
                
                
                
                
                
                
                
                
                <div class="form__input--floating">
                    <label class="form__label--floating" id="label--password">Password</label>

                    <input id="password-field" type="password" placeholder="******" name="password" required>
                    <span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"></span>
                </div>
                <div class="form__input--floating">
                    <label class="form__label--floating" id="label--password">Password Confirmation</label>

                    <input id="password-fields" type="password" placeholder="******" name="password_confirmation"
                           required>
                    <span toggle="#password-fields" class="fa fa-fw fa-eye field-icon toggle-passwords"></span>
                    <small style="color: red" id="passwordvalidation"></small>
                </div>
               <div class="row">
                   <div class="md-col-12 w-100">
                       <div class="login__form_action_container login__form_action_container--multiple-actions">
                           <input type="button" id="registerNext"
                                  class="continue_button btn__primary--large from__button--floating" aria-label="Sign Up"
                                  value="Join"/>
                       </div>
                   </div>
               </div>
                <div class="login__form_action_container text-center">
                    <p>or</p>
                </div>
                
                
                
                <div class="footer-app-content-actions">
                    <div class="login__para">
                        <p>Please read our <a href="<?php echo e(route('policy')); ?>">privacy policy</a> & <a
                                href="<?php echo e(route('terms')); ?>">terms of use</a> here</p>
                    </div>
                    <div class="Signin__class">
                        <p>Already on <img src="assets/img/skilled.png" alt="">?<a href="<?php echo e(route('login')); ?>">Sign
                                in</a></p>
                    </div>
                </div>
            </fieldset>
            <fieldset style="position: relative">
                <div class="pageNumber" style="position: absolute; font-size:12px">2 / 4</div>
                <h2 class="fs-title">Personal Detail</h2>
                <h3 class="fs-subtitle">Tell us something more about you</h3>
                <div class="form__input--floating">
                    <label class="form__label--floating" id="label--first-name">First Name</label>
                    <input id="input--first-name" type="text" value="<?php echo e(old('firstname')); ?>" placeholder="abc"
                           name="firstname">
                </div>
                <div class="form__input--floating">
                    <label class="form__label--floating" id="label--last-name">Last Name</label>
                    <input id="input--last-name" type="text" placeholder="xyz" value="<?php echo e(old('lastname')); ?>"
                           name="lastname">
                    
                </div>
                <div class="row">
                    <div class="md-col-6 w-50 p-1">
                        <div class="login__form_action_container login__form_action_container--multiple-actions">
                            <input type="button" name=""
                                   class="continue_button btn__primary--large from__button--floating"
                                   aria-label="Sign Up" value="Continue"/>
                        </div>
                    </div>
                    <div class="md-col-6 w-50 p-1">
                        <div class="login__form_action_container login__form_action_container--multiple-actions">
                            <input type="button" name="" class="back_button btn__primary--large from__button--floating"
                                   aria-label="Sign Up" value="back"/>
                        </div>
                    </div>
                </div>

            </fieldset>
            <fieldset style="position: relative">
                <div class="pageNumber" style="position: absolute; font-size:12px">3 / 4</div>
                <h2 class="fs-title">Your Location</h2>
                <h3 class="fs-subtitle">Desired location for your network</h3>
                <div class="form__input--floating">
                    <label class="form__label--floating" id="label--country">Country/Region <span>*</span></label>
                    <input id="input--country" type="text" placeholder="Pakistan" value="<?php echo e(old('country')); ?>"
                           name="country">
                </div>
                <div class="form__input--floating">
                    <label class="form__label--floating" id="label--city">City/District <span>*</span></label>
                    <input id="input--city" type="text" placeholder="Lahore" value="<?php echo e(old('city')); ?>" name="city">
                </div>
                <div class="row">
                    <div class="md-col-6 w-50 p-1">
                        <div class="login__form_action_container login__form_action_container--multiple-actions">
                            <input type="button" name=""
                                   class="continue_button btn__primary--large from__button--floating"
                                   aria-label="Sign Up" value="Continue"/>
                        </div>
                    </div>
                    <div class="md-col-6 w-50 p-1">
                        <div class="login__form_action_container login__form_action_container--multiple-actions">
                            <input type="button" name="" class="back_button btn__primary--large from__button--floating"
                                   aria-label="Sign Up" value="back"/>
                        </div>
                    </div>
                </div>


            </fieldset>
            <fieldset style="position: relative">
                <div class="pageNumber" style="position: absolute; font-size:12px">4 / 4</div>
                <h2 class="fs-title">Total experience</h2>
                <h3 class="fs-subtitle">Recent job employment type</h3>
                <div class="form__input--floating">
                    <label class="form__label--floating" id="label--job">Most recent job title <span>*</span></label>
                    <input id="input--job" type="text" placeholder="" value="<?php echo e(old('job_title')); ?>" name="job_title">
                </div>
                <div class="form__input--floating">
                    <label class="form__label--floating" id="label--job">Employment type <span>*</span></label>
                    <select name="employee_type_id" id="input--employment">
                        <option value="">Select One</option>
                        
                        
                        
                        
                        
                    </select>
                </div>
                <div class="form__input--floating">
                    <label class="form__label--floating" id="label--company">Most recent company <span>*</span></label>
                    <input id="input--company" type="text" placeholder="" value="<?php echo e(old('recent_company')); ?>"
                           name="recent_company">
                </div>
                <div>
                    
                    <input type="checkbox" id="vehicle1" name="is_student" value="1">
                    <label for="vehicle1">I am student</label>
                </div>
                <div class="row">
                    <div class="md-col-6 w-50 p-1">
                        <div class=" login__form_action_container login__form_action_container--multiple-actions">
                            <input type="submit" class="continue_button btn__primary--large from__button--floating"
                                   value="Sign up"/>
                        </div>
                    </div>
                    <div class="md-col-6 w-50 p-1">
                        <div class="login__form_action_container login__form_action_container--multiple-actions">
                            <input type="button" name="" class="back_button btn__primary--large from__button--floating"
                                   aria-label="Sign Up" value="back"/>
                        </div>
                    </div>
                </div>

            </fieldset>
        </form>
    </main>
    <script>
        $(document).ready(function () {
            $(document).on('keypress keydown', '#input--email', function () {
                if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(signform.email.value)) {
                    document.getElementById('emailvalidation').innerHTML = ''
                    return
                }
                document.getElementById('emailvalidation').innerHTML = 'please enter valid email address'
                // alert("You have entered an invalid email address!")
                return
            })
            // $(document).on('keypress keydown','#password-fields',function () {
            //     console.log($(this).val())
            //     var password = document.getElementById("password-field").value;
            //     var confirmPassword = document.getElementById("password-fields").value;
            //     if (password != confirmPassword) {
            //         document.getElementById('passwordvalidation').innerHTML='password Not matched'
            //         document.getElementById('registerNext').disabled=true;
            //         return ;
            //     }
            //     document.getElementById('passwordvalidation').innerHTML=''
            //     document.getElementById('registerNext').disabled=false;
            //     return true;
            // })
            $(".toggle-password").click(function () {

                $(this).toggleClass("fa-eye fa-eye-slash");
                var input = $($(this).attr("toggle"));
                if (input.attr("type") == "password") {
                    input.attr("type", "text");
                } else {
                    input.attr("type", "password");
                }
            });
            $(".toggle-passwords").click(function () {

                $(this).toggleClass("fa-eye fa-eye-slash");
                var input = $($(this).attr("toggle"));
                if (input.attr("type") == "password") {
                    input.attr("type", "text");
                } else {
                    input.attr("type", "password");
                }
            });
        })

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('custom.layouts.guest', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/custom/auth/register.blade.php ENDPATH**/ ?>