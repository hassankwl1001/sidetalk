<?php $__env->startSection('content'); ?>
<?php echo $__env->make('custom.inc.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('custom.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div style="padding-top:100px;">

    <?php echo $__env->make('custom.inc.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <h4>Select Ebank</h4>
    <div class="card-header">
        <i class="fa fa-table"></i> Ebanks
        <button style="float: right" type="button" data-toggle="modal" data-target="#addEbank" class="btn btn-primary">Add New</button>
    </div>
<form action="<?php echo e(route('withdrawalRequest')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="table-responsive" >
        <table class="table">
        <thead>
            <tr>
            <th scope="col">Select</th>
            <th scope="col">Name</th>
            <th scope="col">email</th>
            <th scope="col">Added</th>
            <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $userEbanks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ebank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <th scope="row"><input type="radio" name="withdraw" value="<?php echo e($ebank->id); ?>" required></th>
                <td><?php echo e($ebank->ebank->ebank_name); ?></td>
                <td><?php echo e($ebank->email); ?></td>
                <td><?php echo e($ebank->created_at->diffForHumans()); ?></td>
                <td><a href="#" class="btn btn-danger">Remove</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p style="text-align: center">No Ebank</p>
            <?php endif; ?>

        </tbody>
        </table>
    </div>

    <input type="submit" class="btn btn-default withdraw-btn" <?php if($usdEarned <= 1): ?> disabled <?php endif; ?> value="Withdraw">
</form>

    <hr>
    <div class="card-header">
        <i class="fa fa-table"></i> Withdrawals
    </div>

    <div class="table-responsive" >
        <table class="table">
        <thead>
            <tr>
            <th scope="col">#</th>
            <th scope="col">eBank</th>
            <th scope="col">email</th>
            <th scope="col">price</th>
            <th scope="col">date</th>
            <th scope="col">Status</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $withdrawal_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $withdrawal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <th scope="row"><?php echo e($loop->iteration); ?></th>
                <td><?php echo e($withdrawal->userEbank->ebank->ebank_name); ?></td>
                <td><?php echo e($withdrawal->userEbank->email); ?></td>
                <td><?php echo e($withdrawal->price); ?></td>
                <td><?php echo e($withdrawal->created_at); ?></td>
                <td> <?php if($withdrawal->is_approved == 0): ?>
                        <a href="#" class="btn btn-info disabled">Pending</a>
                    <?php elseif($withdrawal->is_approved == 1): ?>
                        <a href="#" class="btn btn-success disabled">Approved</a>
                    <?php elseif($withdrawal->is_approved == -1): ?>
                        <a href="#" class="btn btn-success disabled">Declined</a>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p style="text-align: center">No Withdrawal</p>
            <?php endif; ?>

        </tbody>
        </table>
    </div>
</div>
<div class="modal fade" id="addEbank" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h2 class="modal-title" id="exampleModalLongTitle">Add eBank</h2>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <div class="content">
                <form class="login__form popup__form" id="payment-form" action="<?php echo e(route('addEbank')); ?>" enctype="multipart/form-data" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="message-text" class="col-form-label">Message:</label>
                        <select name="id" class="form-control">
                            <option value="">Select your eBank</option>
                            <?php $__currentLoopData = $ebanks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ebank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($ebank->id); ?>"> <?php echo e($ebank->ebank_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="message-text" class="col-form-label">Enter your Email:</label>
                        <input type="email" name="email" class="form-control" placeholder="Enter email">
                    </div>

                    <input type="submit" class="btn btn-primary" value="Add">
                </form>
            </div>
          </div>
        </div>
    </div>
</div>



<?php echo $__env->make('custom.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/wallet/withdrawal.blade.php ENDPATH**/ ?>