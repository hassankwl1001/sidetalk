<?php $__env->startSection('content'); ?>
<?php echo $__env->make('custom.inc.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('custom.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div style="padding-top:100px;">
    <div class="card mb-3">
        <div class="card-header">
            <i class="fa fa-table"></i> Filter
        </div>
        
            <input type="hidden" name="_token" value="64cx9DthVEm2atcDFQmrEIDqiaTZMQkMmsx1CGIU">            <div class="card-body">
                <div class="row">
                    <div class="col-md-4">
                        <label for="fromDate">Date From</label>
                        <input type="date" name="created_at" id="fromDate" class="form-control">
                    </div>
                    <div class="col-md-4">
                        <label for="toDate">Date To</label>
                        <input type="date" name="date_to" id="toDate" class="form-control">
                    </div>
                </div>
                
<br>
                <input type="submit" class="btn btn-primary" value="Filter">
            </div>
        
    </div>

    <div class="card-header">
        <i class="fa fa-table"></i> Consultations
    </div>

    <div class="table-responsive" >
        <table class="table">
        <thead>
            <tr>
            <th scope="col">#</th>
            <th scope="col">Profile</th>
            <th scope="col">Date</th>
            <th scope="col">Time</th>
            <th scope="col">Type</th>
            <th scope="col">Description</th>
            <th scope="col">Verify</th>
            <th scope="col">Acceptance</th>
            <th scope="col">J oin</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $engagement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $engagement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php
                if($engagement->consultFrom->id == auth()->id()){
                    $user = $engagement->consultWith;
                }else{
                    $user = $engagement->consultFrom;
                }

            ?>
            <tr>
                <th scope="row"><?php echo e($loop->iteration); ?></th>
                <td><img src="<?php if($user->profile_pic !=null): ?><?php echo e($profileUrl); ?>/<?php echo e($user->profile_pic); ?> <?php else: ?> <?php echo e(asset('assets/img/profile.png')); ?> <?php endif; ?>" class="img-size"> <a href="<?php echo e(route('user.profile.show', $user->id)); ?>"><?php echo e($user->firstname); ?> <?php echo e($user->lastname); ?></a></td>
                <td><?php echo e($engagement->date); ?></td>
                <td><?php echo e($engagement->time); ?></td>
                <td><?php echo e($engagement->consult_type); ?></td>
                <td><?php echo e($engagement->desc); ?></td>
                <td> <?php if($engagement->is_approved == 0): ?>
                            <?php if($engagement->consult_from == auth()->id()): ?>
                                <a href="<?php echo e(route('engagements.verify',$engagement->id)); ?>" class="btn btn-success">Verify</a>
                            <?php else: ?>
                                <a href="#" class="btn btn-success disabled">Pending</a>
                            <?php endif; ?>
                        <?php elseif($engagement->is_approved == 1): ?>
                            <?php if($engagement->consult_from == auth()->id()): ?>
                                <a href="#" class="btn btn-success disabled">Approved</a>
                            <?php else: ?>
                                <a href="#" class="btn btn-success disabled">Approved</a>
                            <?php endif; ?>
                        <?php endif; ?>
                </td>
                
                <td>
                    <?php if($engagement->is_accepted == 0): ?>
                        Pending
                    <?php elseif($engagement->is_accepted == 1): ?>
                        Accepted
                    <?php elseif($engagement->is_accepted == -1): ?>
                        Canceled
                    <?php endif; ?>
                </td>
                <td> <a href="<?php echo e(route('user.calling',$engagement->meeting_id)); ?>" class="btn btn-primary <?php if($engagement->is_accepted != 1): ?> disabled <?php endif; ?>">Join</a></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            No Consultation
            <?php endif; ?>

        </tbody>
        </table>
    </div>
</div>

<?php echo $__env->make('custom.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/engagements.blade.php ENDPATH**/ ?>