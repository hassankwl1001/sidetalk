<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="X-UA-Compatible" content="ie=edge" />
    <title>Skilledtalk - SignIn</title>
    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/img/favicon.ico')); ?>" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" />
    <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('assets/js/jquery.inputmask.bundle.js')); ?>"></script>
    <script src="https://kit.fontawesome.com/3f24241a54.js" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-easing/1.3/jquery.easing.min.js"></script>

</head>

<body style="overflow-y: scroll!important;">
<main <?php if(request()->routeIs('login')): ?> class="signup__content" <?php endif; ?>>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('custom.inc.guestFooter', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</main>

</body>
</html>
<?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/custom/layouts/privacyPages.blade.php ENDPATH**/ ?>