<?php $__env->startSection('content'); ?>
<?php echo $__env->make('custom.inc.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('custom.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<style>
    #left-aside-wrapper, #main-wrapper, #right-aside {
        margin-top: 300px;
    }
</style>

    <!-- MAIN CONTAINER -->
    <div class="container">
        <!-- PROFILE -->
        <section id="profile">
            <div class="main-card">
                <?php
                    if(auth()->user()->banner != null){
                        $banner =  $profileUrl."/".auth()->user()->banner;
                    }else{
                        $banner = asset('assets/img/banner.png');
                    }
                ?>
                <div class="profile-info" id="profile-info" style="background-image: url(<?php echo e($banner); ?>); background-size: cover; background-position: center">
                    <div class="profile-image-uploader">
                        <?php if(auth()->user()->profile_pic != null): ?>
                             <img src="<?php echo e($profileUrl); ?>/<?php echo e(auth()->user()->profile_pic); ?>" alt="Profile picture" />
                        <?php else: ?>
                             <img src="<?php echo e(asset('assets/img/profile.png')); ?>" alt="Profile picture" />
                        <?php endif; ?>
                        <a href="" data-toggle="modal" data-target="#image-photo"><i class="fas fa-camera-retro"></i></a>
                    </div>
                    <div class="author-description">
                        <div class="post-name-experience">
                            <strong class="post-author-name"><?php echo e(auth()->user()->firstname); ?> <?php echo e(auth()->user()->lastname); ?>, <?php echo e(auth()->user()->current_position); ?></strong>
                            <span>
                                <span>&nbsp;·&nbsp;</span>
                                <?php echo e(auth()->user()->experience); ?>Y Exp</span>
                        </div>
                        <span class="designation"><?php echo e(auth()->user()->headline); ?></span>
                        
                    </div>
                    <div class="profile-camera">
                        <a href="" data-toggle="modal" data-target="#upload-background-photo"><i class="fas fa-camera-retro"></i></a>
                    </div>
                </div>
                <div class="profile-review">
                    <div class="profile-points">
                        <ul>
                            <li>
                                <i class="far fa-star"></i>
                                <span>Rating</span>
                                <p><?php echo e($totalRating); ?></p>
                            </li>
                            <li>
                                <img src="assets/img/Group8.png" alt="">
                                <span>Reflects</span>
                                <p><?php echo e($totalReflections); ?></p>
                            </li>
                            <li>
                                <i class="far fa-eye"></i>
                                <span>Content Views</span>
                                <p>1.2K</p>
                            </li>
                            <li>
                                <i class="far fa-calendar-alt"></i>
                                <span>Enagements</span>
                                <p>28</p>
                            </li>

                        </ul>
                    </div>
                    <div class="consult-sme">
                        <i data-toggle="modal" data-target="#edit-profile" class="fas fa-cog"></i>
                        <a href="" data-toggle="modal" data-target="#consultation">Consult SME <i class="fas fa-video"></i></a>
                    </div>
                </div>
            </div>
        </section>
        <!-- LEFT ASIDE -->
        <div class="left-aside-wrapper" id="left-aside-wrapper">
            <aside class="left-aside" id="left-aside">
                <div class="profile-groups" id="profile-groups">
                    <section class="profiles-section">
                        <header>
                            <span>Introduction</span>
                            <a href="javascript:void(0)" data-toggle="modal" data-target="#edit-introduction"><i class="far fa-edit"></i></a>
                        </header>
                        <div class="Introduction-details">
                            <small>Company</small>
                            <h2><?php echo e(auth()->user()->recent_company); ?></h2>
                        </div>
                        <div class="Introduction-details">
                            <small>Work Location</small>
                            <h2><?php echo e(auth()->user()->work_location); ?></h2>
                        </div>
                        <div class="Introduction-details">
                            <small>Type of Industry</small>
                            <h2><?php echo e(auth()->user()->industry); ?></h2>
                        </div>
                        <div class="Introduction-details">
                            <small>Industry Sub Category</small>
                            <h2><?php echo e(auth()->user()->sub_industry); ?></h2>
                        </div>
                        <div class="border-space"></div>
                        <div class="Introduction-details">
                            <small>Education</small>
                            <h2><?php echo e(auth()->user()->education); ?></h2>
                        </div>
                        <div class="Introduction-details">
                            <small>Home Town</small>
                            <h2><?php echo e(auth()->user()->city); ?> , <?php echo e(auth()->user()->country); ?></h2>
                        </div>
                    </section>
                </div>
                <div class="rec-section" id="rec-section">
                    <div class="right-sidebar">
                        <header>
                            <span>Experience</span>
                            <a data-toggle="modal" data-target="#add-experience" href="javascript:void(0)"><i class="fa fa-plus-circle"></i></a>
                        </header>
                        <div class="top-right-bar">
                          <?php $__currentLoopData = $experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="top-right-bar-detail">

                                <div class="top-right-bar-description">
                                    <h5><?php echo e($exp->title); ?></h5>
                                    <span><?php echo e($exp->responsibility); ?> at <?php echo e($exp->company); ?></span>
                                    <small><?php echo e($exp->start_date); ?> - <?php echo e($exp->end_date); ?>  .  <?php echo e(\Carbon\Carbon::parse($exp->start_date)->diffAsCarbonInterval(\Carbon\Carbon::parse($exp->end_date))); ?>, <?php echo e($exp->location); ?></small>
                                </div>
                                <a  data-experienced="<?php echo e($exp->id); ?>" class="experienced-edit" href="javascript:void(0)"><i class="far fa-edit"></i></a>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </aside>
        </div>
        <!-- MAIN -->
        <div id="main-wrapper">
            <main class="main-section" id="main-section">
                <?php echo $__env->make('custom.inc.postsCard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php echo $__env->make('custom.inc.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                  <article data-post="<?php echo e($post->id); ?>" class="post-article">
                      <!-- post header -->
                      <div class="post-author">
                          <a href="<?php echo e(route('profile')); ?>">
                              <div class="author-details">
                                  <figure class="image-container">
                                      <?php if($post->user->profile_pic != null): ?>
                                          <img class="img-size" src="<?php echo e($urlProfile); ?>/<?php echo e($post->user->profile_pic); ?>" alt="">
                                      <?php else: ?>
                                          <img class="img-size" src="<?php echo e(asset('assets/img/profile.png')); ?>" alt="">
                                      <?php endif; ?>
                                  </figure>
                                  <div class="author-description">
                                      <div class="post-name-experience">
                                          <strong class="post-author-name"><?php echo e($post->user->firstname); ?> <?php echo e($post->user->lastname); ?></strong>
                                          <span>
                                              <span>&nbsp;·&nbsp;</span>
                                              <?php echo e($post->user->experience); ?>Y Exp</span>
                                          <span class="green_slot">J</span>
                                      </div>
                                      <span class="designation">
                                          <?php if($post->user->is_student == 1): ?> Student |<?php endif; ?>
                                          <?php echo e($post->user->current_position); ?>

                                      </span>
                                      <span class="time-ago"><?php echo e($post->created_at->diffForHumans()); ?></span>
                                  </div>
                              </div>
                          </a>



                              <div class="vertical-icons">
                                  <span class="fas fa-circle"></span>
                                  <span class="fas fa-circle"></span>
                                  <span class="fas fa-circle"></span>
                                  <div class="notifications-signs">
                                      <ul>
                                          <li><a href="save-post.html"><i class="fas fa-save" aria-hidden="true"></i> Save <span class="dropdown-edit">Save for later</span></a></li>
                                          <li><a href=""><i class="fa fa-copy" aria-hidden="true"></i> Copy link to post</a></li>
                                          
                                      </ul>
                                  </div>
                              </div>
                      </div>
                      <!-- /post header -->

                      <!-- post body -->
                      <?php if($post->postType->name == 'Article'): ?>
                        <div class="post-data">
                            <h4 class="article-heading"><?php echo e($post->heading); ?></h4>
                            <p>
                                <?php echo e($post->description); ?>

                            </p>
                            <p class="post-translation">
                                <a href="<?php echo e(route('discover')); ?>?hashtags=<?php echo e(preg_replace("/#/i", "", $post->hashtags)); ?>"><button><?php echo e($post->hashtags); ?></button></a>


                            </p>

                            <?php if(!$post->postMedia->isEmpty()): ?>
                                

                                
                                <iframe src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[0]->name); ?>" width="100%" height="500px"></iframe>
                            <?php endif; ?>

                        </div>
                      <?php elseif($post->postType->name == 'Photo' || $post->postType->name == 'Video'): ?>
                        <div class="post-data">
                            <p>
                                <?php echo e($post->description); ?>

                            </p>
                            <p class="post-translation">
                                <a href="<?php echo e(route('discover')); ?>?hashtags=<?php echo e(preg_replace("/#/i", "", $post->hashtags)); ?>"><button><?php echo e($post->hashtags); ?></button></a>


                            </p>
                            <?php
                                $mediaCount = count($post->postMedia);
                            ?>
                            <?php if($mediaCount == 1): ?>
                                <?php if($post->postType->name == 'Photo'): ?>
                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[0]->name); ?>" class="postMediaContent" alt="Modal Image" />
                                <?php elseif($post->postType->name == 'Video'): ?>
                                <video style="width: 100%;" controls>
                                    <source src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[0]->name); ?>" type="video/mp4">
                                    <source src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[0]->name); ?>" type="video/mkv">
                                    Your browser does not support HTML video.
                                </video>
                                <?php endif; ?>
                            <?php else: ?>

                                <?php if($mediaCount == 2): ?>
                                <div class="row">
                                    <div class="col-md-6 imgShowColumn1">
                                    <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[0]->name); ?>" class="postImage postMediaContent" alt="" />
                                    </div>
                                    <div class="col-md-6 imgShowColumn2">
                                    <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[1]->name); ?>" class="postImage postMediaContent" alt="" />
                                    </div>
                                </div>
                                <?php elseif($mediaCount == 3): ?>
                                <div class="row">
                                    <div class="col-md-12 singleImage">
                                    <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[0]->name); ?>" class="postMediaContent" alt="" />
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 imgShowColumn1">
                                    <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[0]->name); ?>" class="postImage postMediaContent" alt="" />
                                    </div>
                                    <div class="col-md-6 imgShowColumn2">
                                    <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[1]->name); ?>" class="postImage postMediaContent" alt="" />
                                    </div>
                                </div>
                                <?php elseif($mediaCount == 4): ?>
                                <div class="row">
                                    <div class="col-md-6 imgShowColumn1">
                                    <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[0]->name); ?>" class="postImage postMediaContent" alt="" />
                                    </div>
                                    <div class="col-md-6 imgShowColumn2">
                                    <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[1]->name); ?>" class="postImage postMediaContent" alt="" />
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 imgShowColumn3">
                                    <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[2]->name); ?>" class="postImage postMediaContent" alt="" />
                                    </div>
                                    <div class="col-md-6 imgShowColumn4">
                                    <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[3]->name); ?>" class="postImage postMediaContent" alt="" />
                                    </div>
                                </div>
                                <?php elseif($mediaCount > 4): ?>
                                <div class="row">
                                    <div class="col-md-12">
                                    <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[0]->name); ?>" class="postMediaContent" alt="" />
                                    </div>
                                </div>
                                <br>
                                <div class="row">
                                <div class="col-md-4 imgShowColumn1">
                                    <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[1]->name); ?>" class="postMediaContent" alt="" />
                                </div>
                                <div class="col-md-4 imgShowColumn2 imgShowColumn3">
                                    <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[2]->name); ?>" class="postMediaContent" alt="" />
                                </div>
                                <div class="col-md-4 imgShowColumn3" id="moreImagesbox">
                                <span id="moreImages">
                                        +<?php echo e($mediaCount - 3); ?>

                                    </span>
                                </div>
                                </div>

                                <?php endif; ?> <!-- /count == 2 -->
                            <?php endif; ?> <!-- /count == 1 -->

                        </div>
                      <?php elseif($post->postType->name == 'Job'): ?>
                        <div class="job-post-data">
                            <img src="<?php echo e($urlPost); ?>/<?php echo e($post->postMedia[0]->name); ?>" alt="" />
                            <div class="job-post-details">
                                <h2><?php echo e($post->jobs->job_title); ?></h2>
                                <p><?php echo e($post->jobs->description); ?></p>
                                <div class="job-post-descrption-detail">
                                    <span><?php echo e($post->jobs->location); ?></span> .
                                    <span><?php echo e($post->jobs->employeeType->name); ?></span> .
                                    <span><?php echo e($post->jobs->salary_from); ?>-<?php echo e($post->jobs->salary_to); ?>k /month</span>
                                    <a class="btn-primary" href="<?php echo e(route('job.detail', $post->jobs->id)); ?>">Apply now</a>

                                </div>
                            </div>
                        </div>
                     <?php elseif($post->postType->name == 'Shared'): ?>
                        <div class="job-post-data">
                            

                               <!-- post header -->
                                <div class="post-author">
                                    <a href="profile.html">
                                        <div class="author-details">
                                            <figure class="image-container">
                                                <?php if($post->shared->user->profile_pic != null): ?>
                                                    <img class="img-size" src="<?php echo e($urlProfile); ?>/<?php echo e($post->shared->user->profile_pic); ?>" alt="">
                                                <?php else: ?>
                                                    <img class="img-size" src="<?php echo e(asset('assets/img/profile.png')); ?>" alt="">
                                                <?php endif; ?>
                                            </figure>
                                            <div class="author-description">
                                                <div class="post-name-experience">
                                                    <strong class="post-author-name"><?php echo e($post->shared->user->firstname); ?> <?php echo e($post->shared->user->lastname); ?></strong>
                                                    <span>
                                                        <span>&nbsp;·&nbsp;</span>
                                                        <?php echo e($post->shared->user->experience); ?>Y Exp</span>
                                                    <span class="green_slot">J</span>
                                                </div>
                                                <span class="designation">
                                                    <?php if($post->shared->user->is_student == 1): ?> Student |<?php endif; ?>
                                                    <?php echo e($post->shared->user->current_position); ?>

                                                </span>
                                                <span class="time-ago"><?php echo e($post->shared->created_at->diffForHumans()); ?></span>
                                            </div>
                                        </div>
                                    </a>
                                </div>
                                <!-- /post header -->

                                
                                <?php if($post->shared->postType->name == 'Article'): ?>
                                <div class="post-data">
                                    <h4 class="article-heading"><?php echo e($post->shared->heading); ?></h4>
                                    <p>
                                        <?php echo e($post->shared->description); ?>

                                    </p>
                                    <p class="post-translation">
                                        <a href="<?php echo e(route('discover')); ?>?hashtags=<?php echo e(preg_replace("/#/i", "", $post->hashtags)); ?>"><button><?php echo e($post->hashtags); ?></button></a>


                                    </p>

                                    <?php if(!$post->shared->postMedia->isEmpty()): ?>
                                        

                                        
                                        <iframe src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[0]->name); ?>" width="100%" height="500px"></iframe>
                                    <?php endif; ?>

                                </div>
                                <?php elseif($post->shared->postType->name == 'Photo' || $post->postType->name == 'Video'): ?>
                                    <div class="post-data">
                                        <p>
                                            <?php echo e($post->shared->description); ?>

                                        </p>
                                        <p class="post-translation">
                                            <a href="<?php echo e(route('discover')); ?>?hashtags=<?php echo e(preg_replace("/#/i", "", $post->hashtags)); ?>"><button><?php echo e($post->hashtags); ?></button></a>


                                        </p>
                                        <?php
                                            $mediaCount = count($post->shared->postMedia);
                                        ?>
                                        <?php if($mediaCount == 1): ?>
                                            <?php if($post->shared->postType->name == 'Photo'): ?>
                                            <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[0]->name); ?>" class="postMediaContent" alt="Modal Image" />
                                            <?php elseif($post->shared->postType->name == 'Video'): ?>
                                            <video style="width: 100%;" controls>
                                                <source src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[0]->name); ?>" type="video/mp4">
                                                <source src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[0]->name); ?>" type="video/mkv">
                                                Your browser does not support HTML video.
                                            </video>
                                            <?php endif; ?>
                                        <?php else: ?>

                                            <?php if($mediaCount == 2): ?>
                                            <div class="row">
                                                <div class="col-md-6 imgShowColumn1">
                                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[0]->name); ?>" class="postImage postMediaContent" alt="" />
                                                </div>
                                                <div class="col-md-6 imgShowColumn2">
                                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[1]->name); ?>" class="postImage postMediaContent" alt="" />
                                                </div>
                                            </div>
                                            <?php elseif($mediaCount == 3): ?>
                                            <div class="row">
                                                <div class="col-md-12 singleImage">
                                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[0]->name); ?>" class="postMediaContent" alt="" />
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6 imgShowColumn1">
                                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[0]->name); ?>" class="postImage postMediaContent" alt="" />
                                                </div>
                                                <div class="col-md-6 imgShowColumn2">
                                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[1]->name); ?>" class="postImage postMediaContent" alt="" />
                                                </div>
                                            </div>
                                            <?php elseif($mediaCount == 4): ?>
                                            <div class="row">
                                                <div class="col-md-6 imgShowColumn1">
                                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[0]->name); ?>" class="postImage postMediaContent" alt="" />
                                                </div>
                                                <div class="col-md-6 imgShowColumn2">
                                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[1]->name); ?>" class="postImage postMediaContent" alt="" />
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6 imgShowColumn3">
                                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[2]->name); ?>" class="postImage postMediaContent" alt="" />
                                                </div>
                                                <div class="col-md-6 imgShowColumn4">
                                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[3]->name); ?>" class="postImage postMediaContent" alt="" />
                                                </div>
                                            </div>
                                            <?php elseif($mediaCount > 4): ?>
                                            <div class="row">
                                                <div class="col-md-12">
                                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[0]->name); ?>" class="postMediaContent" alt="" />
                                                </div>
                                            </div>
                                            <br>
                                            <div class="row">
                                            <div class="col-md-4 imgShowColumn1">
                                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[1]->name); ?>" class="postMediaContent" alt="" />
                                            </div>
                                            <div class="col-md-4 imgShowColumn2 imgShowColumn3">
                                                <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[2]->name); ?>" class="postMediaContent" alt="" />
                                            </div>
                                            <div class="col-md-4 imgShowColumn3" id="moreImagesbox">
                                            <span id="moreImages">
                                                    +<?php echo e($mediaCount - 3); ?>

                                                </span>
                                            </div>
                                            </div>

                                            <?php endif; ?> <!-- /count == 2 -->
                                        <?php endif; ?> <!-- /count == 1 -->

                                    </div>
                                <?php elseif($post->shared->postType->name == 'Job'): ?>
                                    <div class="job-post-data">
                                        <img src="<?php echo e($urlPost); ?>/<?php echo e($post->shared->postMedia[0]->name); ?>" alt="" />
                                        <div class="job-post-details">
                                            <h2><?php echo e($post->shared->jobs->job_title); ?></h2>
                                            <p><?php echo e($post->shared->jobs->description); ?></p>
                                            <div class="job-post-descrption-detail">
                                                <span><?php echo e($post->shared->jobs->location); ?></span> .
                                                <span><?php echo e($post->shared->jobs->employeeType->name); ?></span> .
                                                <span><?php echo e($post->shared->jobs->salary_from); ?>-<?php echo e($post->shared->jobs->salary_to); ?>k /month</span>
                                                <a class="btn-primary" href="jobs-detail.html">Apply now</a>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                
                        </div>
                      <?php endif; ?>
                      <!-- /post body -->

                      <!-- post interactions -->
                      <div class="post-interactions">
                          <div class="interactions-amount">
                              <div class="rating-stars">
                                  <ul id="stars">
                                    <li class="star 1 2 3 4 5 <?php if(!$post->rate->isEmpty() && $post->rate[0]->stars >= 1): ?> selected <?php endif; ?>" title="Poor" data-value="1"  data-rate="<?php if(!$post->rate->isEmpty()): ?> <?php echo e($post->rate[0]->id); ?> <?php endif; ?>">
                                      <i class="fa fa-star fa-fw"></i>
                                    </li>
                                    <li class="star 2 3 4 <?php if(!$post->rate->isEmpty() && $post->rate[0]->stars >= 2 ): ?> selected <?php endif; ?>" title="Fair" data-value="2" data-rate="<?php if(!$post->rate->isEmpty()): ?> <?php echo e($post->rate[0]->id); ?> <?php endif; ?>">
                                      <i class="fa fa-star fa-fw"></i>
                                    </li>
                                    <li class="star 3 4 5 <?php if(!$post->rate->isEmpty() && $post->rate[0]->stars >= 3): ?> selected <?php endif; ?>" title="Good" data-value="3" data-rate="<?php if(!$post->rate->isEmpty()): ?> <?php echo e($post->rate[0]->id); ?> <?php endif; ?>">
                                      <i class="fa fa-star fa-fw"></i>
                                    </li>
                                    <li class="star 4 5 <?php if(!$post->rate->isEmpty() && $post->rate[0]->stars >= 4): ?> selected <?php endif; ?>" title="Excellent" data-value="4" data-rate="<?php if(!$post->rate->isEmpty()): ?> <?php echo e($post->rate[0]->id); ?> <?php endif; ?>">
                                      <i class="fa fa-star fa-fw"></i>
                                    </li>
                                    <li class="star 5 <?php if(!$post->rate->isEmpty() && $post->rate[0]->stars == 5): ?> selected <?php endif; ?>" title="WOW!!!" data-value="5" data-rate="<?php if(!$post->rate->isEmpty()): ?> <?php echo e($post->rate[0]->id); ?> <?php endif; ?>">
                                      <i class="fa fa-star fa-fw"></i>
                                    </li>
                                  </ul>
                              </div>
                              <span class="amount-info">128 Views</span>
                          </div>
                          <div class="interactions-btns">
                            <?php if($post->rate->isEmpty()): ?>
                              <button>
                                <span class="counter ratePost"><i class="far fa-star"></i></span>
                                <span class="ratePost rateCounter">Rate [<?php echo e($post->rate_count); ?>]</span>
                              </button>
                            <?php else: ?>
                              <button>
                                <span class="counter ratePost"><i class="fa fa-star fa-clicked"></i></span>
                                <span class="ratePost rateCounter">Rate [<?php echo e($post->rate_count); ?>]</span>
                              </button>
                            <?php endif; ?>

                              <button>
                                  <span class="counter"><img src="assets/img/Group8.png" alt=""></span>
                                  <span>Reflect [<?php echo e($post->reflections_count); ?>]</span>
                              </button>
                              <button class="repost-button">
                                  <span class="counter"><img src="assets/img/Group5.png" alt=""></span>
                                  <span>Repost [99]</span>
                              </button>
                              <button>
                                  <span class="counter"><i class="fas fa-paper-plane"></i></span>
                                  <span>Send</span>
                              </button>
                          </div>
                      </div>
                      <!-- /post interactions -->

                      <!-- add new comment -->
                      <div class="post-input">
                          <div class="input-section">
                              <figure class="image-container">
                                  <img class="img-size" src="<?php echo e($urlProfile); ?>/<?php echo e(auth()->user()->profile_pic); ?>" alt="">
                              </figure>
                              <div class="input-portion">
                                  <div>
                                      <input class="form-control reflection" type="text" placeholder="Add a reflection">
                                  </div>
                              </div>
                          </div>
                      </div>
                      <!-- /add new comment -->

                      <!-- previous comments -->
                      <div class="commented-groups">
                          <section>
                              <header>
                                  <span class="heading-commented">Recent Reflections</span>
                                  <span
                                      class="fas fa-angle-down"
                                      onclick="toggleProfileGroupList(this)"
                                  ></span>
                              </header>
                              <ul class="group-list reflection-list">
                                <?php $__currentLoopData = $post->reflections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reflection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <li>
                                      <div class="operations-user">
                                          <figure class="image-container">
                                            <?php if($reflection->user->profile_pic != null): ?>
                                                <img class="img-size" src="<?php echo e($urlProfile); ?>/<?php echo e($reflection->user->profile_pic); ?>" alt="">
                                            <?php else: ?>
                                                <img class="img-size" src="<?php echo e(asset('assets/img/profile.png')); ?>" alt="">
                                            <?php endif; ?>
                                          </figure>
                                          <div class="box-commented">
                                              <div class="commented-description">
                                                  <strong class="post_name"><?php echo e($reflection->user->firstname); ?> <?php echo e($reflection->user->lastname); ?></strong>
                                                  <span class="post_designation">
                                                      <span>&nbsp;·&nbsp;</span>
                                                      <?php echo e($reflection->user->experience); ?>Y Exp
                                                    </span>
                                              </div>
                                              <span class="designation"><?php echo e($reflection->user->current_position); ?></span>
                                              <span class="comment-user"><?php echo e($reflection->reflection); ?></span>
                                          </div>
                                      </div>



                                  </li>
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </ul>
                              <div class="load-more">
                                  <a href="" data-value="0">Load more reflections</a>
                              </div>
                          </section>
                      </div>
                      <!-- /previous comments -->
                  </article>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </main>
        </div>
        <!-- RIGHT ASIDE -->
        <aside class="right-aside" id="right-aside">
            
            <div class="rec-section" id="rec-section">
                <div class="right-sidebar">
                    <header>
                        <span>Follows</span>
                        <span class="default-span"><?php echo e($totalPages); ?> Follows</span>
                    </header>
                    <div class="top-right-bar" style="max-height: 300px;overflow-y: scroll">
                        

                        <?php $__currentLoopData = $follows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <div class="top-right-bar-detail">
                                <img src="<?php echo e(env('PAGE_CONTENT_URL')); ?>/<?php echo e($page->logo); ?>" alt="">
                                <div class="top-right-bar-description">
                                    <strong><?php echo e($page->name); ?></strong>
                                    <small><?php echo e($page->tagline); ?></small>
                                </div>



                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <a href="<?php echo e(route('pages.list')); ?>">Discover more</a>
                </div>
            </div>
        </aside>
    </div>


    <?php echo $__env->make('custom.inc.postsCardModels', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('custom.inc.consultationModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
















































































































































































































    <div class="modal fade" id="upload-background-photo" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h2 class="modal-title" id="exampleModalLongTitle">Add Background Photo</h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div class="content">
                    <form class="login__form popup__form" action="<?php echo e(route('profile.update')); ?>" enctype="multipart/form-data" method="post">
                        <?php echo csrf_field(); ?>
                      <div class="form__input--floating photo_upload">

                        <input id="background_imageupload" name="banner_pic" type="file"/>
                        <div id="background_image"></div>

                      </div>

                      <div class="login__form_icons login__form_action_container login__form_action_container--multiple-actions">
                        <button class="btn__primary--large from__button--floating" type="submit" aria-label="">Upload a photo</button>
                      </div>
                    </form>
                </div>
              </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="edit-profile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h2 class="modal-title" id="exampleModalLongTitle">Edit Profile</h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div class="content">
                    <div class="profile-info" id="profile-info">
                        <?php if(auth()->user()->profile_pic != null): ?>
                                <img src="<?php echo e($profileUrl); ?>/<?php echo e(auth()->user()->profile_pic); ?>" alt="Profile picture" />
                        <?php else: ?>
                            <img src="<?php echo e(asset('assets/img/profile.png')); ?>" alt="Profile picture" />
                        <?php endif; ?>
                    </div>
                    <form class="login__form popup__form" action="<?php echo e(route('profile.update')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                      <div class="form__input--floating">
                        <div class="form__input--floating two-column-grid-first">
                            <label class="form__label--floating" id="label--first">First Name <span>*</span></label>
                            <input id="input--first" type="text" placeholder="" value="<?php echo e(auth()->user()->firstname); ?>" name="firstname">
                        </div>
                        <div class="form__input--floating two-column-grid-second">
                            <label class="form__label--floating" id="label--last">Last Name <span>*</span></label>
                            <input id="input--last" type="text" placeholder="" value="<?php echo e(auth()->user()->lastname); ?>" name="lastname">
                        </div>
                      </div>
                      <div class="form__input--floating">
                        <label class="form__label--floating" id="label--session-price">Phone <span>*</span></label>
                        <input id="input--session-price" type="text" value="<?php echo e(auth()->user()->phone); ?>" placeholder="+923120796726" name="phone">
                      </div>
                      <div class="form__input--floating">
                        <label class="form__label--floating" id="label--session-price">Add your skills <span>*</span></label>
                        <input id="skills_input_field" type="text" value="" placeholder="" name="skills">
                        <ul id="skills_search_result" style="height: auto !important; width:100% !important">
                        </ul>
                        <br><br>
                        <button type="button" class="btn btn-primary" id="addNewSkillButton">Add</button>
                        <b>Added:</b>
                        <?php $__empty_1 = true; $__currentLoopData = auth()->user()->skills()->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php echo e($skill->name . ','); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            No Skill Found
                        <?php endif; ?>

                      </div>
                      <div class="form__input--floating">
                        <label class="form__label--floating" id="label--session-price">Add Session Price in USD <span>*</span></label>
                        <input id="input--session-price" type="text" placeholder="" value="<?php echo e(auth()->user()->session_price); ?>" name="session_price">
                      </div>
                      <div class="form__input--floating">
                        <label class="form__label--floating" id="label--headline">Headline <span>*</span></label>
                        <input id="input--headline" type="text" placeholder="" value="<?php echo e(auth()->user()->headline); ?>" name="headline">
                      </div>
                      <div class="form__input--floating">
                        <label class="form__label--floating" id="label--position">Current Position <span>*</span></label>
                        <input id="input--position" type="text" placeholder="" value="<?php echo e(auth()->user()->current_position); ?>" name="current_position">
                      </div>


                      <div class="login__form_action_container login__form_action_container--multiple-actions editprofile-btn">
                        <input type="submit" value="Save" class="btn__primary--large from__button--floating">
                      </div>
                    </form>
                </div>
              </div>
            </div>
        </div>
    </div>


    <div class="modal fade" id="add-experience" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h2 class="modal-title" id="exampleModalLongTitle">Add Experience</h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div class="content">
                    <form class="login__form popup__form" action="<?php echo e(route('experience')); ?>" method="post">
                      <?php echo csrf_field(); ?>
                      <div class="form__input--floating">
                        <label class="form__label--floating" id="label--experience-title">Title <span>*</span></label>
                        <input type="text" id="input--experience-title" placeholder="Ex: Experience Title" name="title" required />
                      </div>
                      <div class="form__input--floating">
                        <label class="form__label--floating" id="label--emp-type">Employment Type <span>*</span></label>
                        <div class="form__label--dropdown">
                            <select class="mr-0" name="employee_type_id" id="input--emp-type" required>
                                <option>Select Employment Type</option>
                                <?php $__currentLoopData = $employeeTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type->id); ?>"> <?php echo e($type->name); ?> </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                      </div>
                      <div class="form__input--floating">
                        <label class="form__label--floating" id="label--company">Company <span>*</span></label>
                        <input type="text" id="input--company" placeholder="Enter Company Name" name="company" required />
                      </div>
                      <div class="form__input--floating">
                        <div class="form__label--dropdown row">
                            <div class="col-md-6 paddingleft">
                                <label class="form__label--floating" id="label--experience">Start Date <span>*</span></label>
                                <input type="date"  name="start_date" required />
                            </div>
                            <div class="col-md-6 paddingright">
                                <label class="form__label--floating" id="label--experience">End Date <span>*</span></label>
                                <input type="date"  name="end_date" required />
                            </div>
                        </div>
                      </div>
                      <div class="form__input--floating">
                        <label class="form__label--floating" id="label--heading">Responsibility <span>*</span></label>
                        <input type="text" id="input--heading" placeholder="Enter your responsibility" required name="responsibility" />
                      </div>
                      <div class="form__input--floating">
                        <label class="form__label--floating" id="label--heading">Location <span>*</span></label>
                        <input type="text" id="input--heading" placeholder="Enter Work Location" required name="location" />
                      </div>

                      <div class="login__form_action_container login__form_action_container--multiple-actions">
                        <button class="btn__secondary--large from__button--floating" data-dismiss="modal" aria-label="">Back</button>
                        <button class="btn__primary--large from__button--floating" type="submit" aria-label="">Submit</button>
                      </div>
                    </form>
                </div>
              </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="edit-experience" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content" id="EditExperienceModal">
            </div>
        </div>
    </div>

    <div class="modal fade" id="report-post" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered  modal-md" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h2 class="modal-title" id="exampleModalLongTitle">Select a reporting reason:</h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div class="content">
                    <form class="login__form popup__form" action="" method="post">
                      <div class="form__input--floating billing-cycle reporting-post">
                        <div class="payment-plans">
                            <span>
                                <input type="radio" name="report-posts" value="">
                                <label>Suspicious or fake</label>
                            </span>
                        </div>
                        <div class="payment-plans">
                            <span>
                                <input type="radio" name="report-posts" value="">
                                <label>Harassment or hateful speech</label>
                            </span>
                        </div>
                        <div class="payment-plans">
                            <span>
                                <input type="radio" name="report-posts" value="">
                                <label>Violence or physical harm</label>
                            </span>
                        </div>
                        <div class="payment-plans">
                            <span>
                                <input type="radio" name="report-posts" value="">
                                <label>Adult content</label>
                            </span>
                        </div>
                        <div class="payment-plans">
                            <span>
                                <input type="radio" name="report-posts" value="">
                                <label>Intellectual property infringement or defamation</label>
                            </span>
                        </div>
                      </div>
                      <div class="login__form_action_container login__form_action_container--multiple-actions">
                        <button class="btn__secondary--large from__button--floating" data-dismiss="modal" aria-label="">Back</button>
                        <button class="btn__primary--large from__button--floating" type="submit" aria-label="">Submit</button>
                      </div>
                    </form>
                </div>
              </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="image-photo" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h2 class="modal-title" id="exampleModalLongTitle">Add Profile Photo</h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div class="content">
                    <form class="login__form popup__form" action="<?php echo e(route('profile.update')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                      <div class="form__input--floating photo_upload">

                        <input id="fileUpload" name="profile_photo" type="file"/>
                        <div id="image-holder"></div>


                      </div>

                      <div class="login__form_icons login__form_action_container login__form_action_container--multiple-actions">
                        <button class="btn__primary--large from__button--floating" type="submit" aria-label="">Upload a photo</button>
                      </div>
                    </form>
                </div>
              </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="payment-popup" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
              <div class="modal-header">
                <h2 class="modal-title" id="exampleModalLongTitle">Consultation Payment</h2>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
              <div class="modal-body">
                <div class="content">
                    <form class="login__form" action="" method="post">
                      <div class="form__input--floating">
                        <label class="form__label--floating" id="label--fname">First Name <span>*</span></label>
                        <input id="input--fname" type="text" placeholder="" name="fname">
                      </div>
                      <div class="form__input--floating">
                        <label class="form__label--floating" id="label--lname">Last Name <span>*</span></label>
                        <input id="input--lname" type="text" placeholder="" name="lname">
                      </div>
                      <div class="form__input--floating">
                        <label class="form__label--floating" id="label--card">Credit or debit card number <span>*</span></label>
                        <input id="input--card" type="text" placeholder="" data-inputmask="'mask': '9999 9999 9999 9999'" name="card">
                      </div>
                      <div class="form__input--floating two-column-grid-first">
                        <label class="form__label--floating" id="label--expiration">Expiration date <span>*</span></label>
                        <input id="input--expiration" type="text" placeholder="" data-inputmask="'alias': 'date'" name="expiration">
                      </div>
                      <div class="form__input--floating two-column-grid-second">
                        <label class="form__label--floating" id="label--security">Security code <span>*</span></label>
                        <input id="input--security" type="text" placeholder="" name="security">
                      </div>
                      <div class="form__input--floating">
                        <label class="form__label--floating" id="label--postal">Postal code <span>*</span></label>
                        <input id="input--postal" type="text" placeholder="" name="postal">
                      </div>

                      <div class="login__form_action_container login__form_action_container--multiple-actions">
                        <a href="" class="btn__primary--large from__button--floating" type="submit" aria-label="">Confirm</a>
                      </div>
                    </form>
                </div>
              </div>
            </div>
        </div>
    </div>

    <div class="modal fade" id="edit-introduction" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h2 class="modal-title" id="exampleModalLongTitle">Edit Introduction</h2>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <div class="content">
                  <form class="login__form popup__form" action="<?php echo e(route('profile.update')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="form__input--floating">
                      <label class="form__label--floating" id="label--company">Company <span>*</span></label>
                      <input id="input--session-company" type="text" value="<?php echo e(auth()->user()->recent_company); ?>" placeholder="Enter Company Name" name="recent_company">
                    </div>
                    <div class="form__input--floating">
                      <label class="form__label--floating" id="label--city">Work location <span>*</span></label>
                      <input id="input--city" type="text" value="<?php echo e(auth()->user()->work_location); ?>" placeholder="Enter wok location" name="work_location">
                    </div>

                    <div class="form__input--floating">
                      <label class="form__label--floating" id="label--industry">Industry <span>*</span></label>
                      <input id="input--industry" type="text" value="<?php echo e(auth()->user()->industry); ?>" placeholder="Type of Industry" name="industry">
                    </div>
                    <div class="form__input--floating">
                      <label class="form__label--floating" id="label--main-industry">Industry Sub Category <span>*</span></label>
                      <input id="input--main-industry" type="text" value="<?php echo e(auth()->user()->sub_industry); ?>" placeholder="Industry Sub Category" name="sub_industry">
                    </div>
                    <div class="form__input--floating">
                      <label class="form__label--floating" id="label--education">Education <span>*</span></label>
                      <textarea id="input--education" type="text" placeholder="" value="<?php echo e(auth()->user()->education); ?>" name="education"><?php echo e(auth()->user()->education); ?></textarea>
                    </div>

                    <div class="form__input--floating">
                      <label class="form__label--floating" id="label--country">Home Country <span>*</span></label>

                        <div class="form__label--dropdown">
                            <select class="mr-0" name="country" id="input--emp-type" required>
                                <option>Select Country</option>
                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($country->id == auth()->user()->country): ?>
                                    <option selected value="<?php echo e($country->id); ?>"> <?php echo e($country->name); ?> </option>
                                    <?php else: ?>
                                    <option value="<?php echo e($country->id); ?>"> <?php echo e($country->name); ?> </option>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="form__input--floating">
                      <label class="form__label--floating" id="label--location">Home Location <span>*</span></label>
                      <input id="input--location" type="text" placeholder="" value="<?php echo e(auth()->user()->city); ?>" name="city">
                    </div>

                    <div class="login__form_action_container login__form_action_container--multiple-actions editprofile-btn">
                      
                      <input type="submit" class="btn__primary--large from__button--floating" value="Save">
                    </div>
                  </form>
              </div>
            </div>
          </div>
      </div>
  </div>

  <?php echo $__env->make('custom.inc.chatWidget', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <?php echo $__env->make('custom.inc.pushNotifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('custom.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/savedPost.blade.php ENDPATH**/ ?>