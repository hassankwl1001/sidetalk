<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3431362589381697"
                crossorigin="anonymous"></script>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('assets/img/favicon.ico')); ?>" />
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
        <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>" />
        <script src="https://code.jquery.com/jquery-3.5.1.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
        <script src="<?php echo e(asset('assets/js/script.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jquery.inputmask.bundle.js')); ?>"></script>
        <script src="https://kit.fontawesome.com/3f24241a54.js" crossorigin="anonymous"></script>
        <!-- toaster library -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js" defer></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
        <?php if(\Request::route()->getName() == 'inbox'): ?>
        <script src="<?php echo e(asset('assets/js/chat.js')); ?>"></script>
        <?php endif; ?>
        <script src="https://js.pusher.com/7.0/pusher.min.js"></script>

    </head>
    <body class="font-sans antialiased">



        <?php echo $__env->yieldContent('content'); ?>
    </body>
</html>
<?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/custom/layouts/app.blade.php ENDPATH**/ ?>