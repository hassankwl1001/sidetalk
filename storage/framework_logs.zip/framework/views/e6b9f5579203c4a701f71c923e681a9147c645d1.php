<?php $__env->startSection('content'); ?>
<?php echo $__env->make('custom.inc.loading', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('custom.inc.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<section class="tag-section inner-padding-top">
    <div class="container default-container">
        <div class="row marginleftright">
            <div class="col-12 tag-count">
                <h6>Search for your next job</h6>
                <form>
                    <div class="row">
                        <div class="col-md-5">
                            <div class="form__input--floating">
                                <label class="form__label--floating" id="label--text">Search Job</label>
                                <div class="search-jobs">
                                    <i class="fas fa-search"></i>
                                    <input id="input--text" type="text" placeholder="Search by title, skill or company" name="search">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5">
                            <div class="form__input--floating">
                                <label class="form__label--floating" id="label--text">City</label>
                                <div class="search-jobs">
                                    <i class="fas fa-map-marker-alt"></i>
                                    <input id="input--text" type="text" placeholder="Pakistan" name="search">
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <button class="btn__primary--large from__button--floating">Search</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<section class="tag-list searchjob-lists">
    <div class="container default-container">
        <div class="row marginleftright">
            <div class="col-12 paddingleftright">
                <div class="">
                </div>
                <ul>
                    <?php $__empty_1 = true; $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li>
                        <?php if($job->userApplicant->isEmpty()): ?>
                        <a href="<?php echo e(route('job.detail', $job->id)); ?>">
                            <div class="hashtag job-lists">
                                <img class="job-logo" style="height: 150px;" src="<?php echo e($urlPost); ?>/<?php echo e($job->postMedia[0]->name); ?>" alt="">
                                <h3><?php echo e($job->jobs->job_title); ?></h3>
                                <span><?php echo e($job->jobs->company); ?></span>
                                <span><?php echo e($job->jobs->location); ?></span>
                                
                                <hr/>
                                <span><?php echo e($job->created_at->diffForHumans()); ?> . <span class="color-green">11 applicants</span></span>
                            </div>
                        </a>
                        <?php else: ?>

                                <div class="hashtag job-lists">
                                    <img class="job-logo" src="<?php echo e($urlPost); ?>/<?php echo e($job->postMedia[0]->name); ?>" alt="">
                                    <h3><?php echo e($job->jobs->job_title); ?></h3>
                                    <span><?php echo e($job->jobs->company); ?></span>
                                    <span><?php echo e($job->jobs->location); ?></span>
                                    
                                    <hr/>
                                    <span><?php echo e($job->created_at->diffForHumans()); ?> . <span class="color-green"> Applied</span></span>
                                </div>

                        <?php endif; ?>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <p style="text-align: center">No Job Found</p>
                    <?php endif; ?>

                </ul>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('custom.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u145108670/domains/skilledtalk.com/public_html/resources/views/job/jobs.blade.php ENDPATH**/ ?>